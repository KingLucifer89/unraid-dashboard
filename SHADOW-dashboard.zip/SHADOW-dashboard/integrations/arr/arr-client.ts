import { IntegrationProvider, IntegrationConfigData } from '../core/types';

export class ArrProvider implements IntegrationProvider {
  id: string;
  name: string;
  type = 'arr' as const;
  description: string;
  defaultPort: number;

  constructor(id: string, name: string, defaultPort: number, description: string) {
    this.id = id;
    this.name = name;
    this.defaultPort = defaultPort;
    this.description = description;
  }

  async connect(config: IntegrationConfigData): Promise<boolean> {
    const res = await this.testConnection(config);
    return res.success;
  }

  async testConnection(config: IntegrationConfigData): Promise<{ success: boolean; message: string; version?: string }> {
    if (!config.url) return { success: false, message: 'Server-URL fehlt.' };
    const cleanUrl = config.url.replace(/\/$/, '');
    try {
      const res = await fetch(`${cleanUrl}/api/v3/system/status`, {
        headers: config.apiKey ? { 'X-Api-Key': config.apiKey } : {},
        signal: AbortSignal.timeout(4000),
      });
      if (res.ok) {
        const data = await res.json();
        return { success: true, message: `${this.name} API verbunden.`, version: data.version || 'v3.0.0' };
      }
      return { success: false, message: `HTTP Fehler ${res.status}` };
    } catch (err: unknown) {
      return { success: false, message: `Verbindung nicht möglich: ${err instanceof Error ? err.message : String(err)}` };
    }
  }

  async getQueue(config: IntegrationConfigData): Promise<Array<{ title: string; size: number; status: string; timeleft?: string }>> {
    if (!config.url || !config.apiKey) return [];
    try {
      const cleanUrl = config.url.replace(/\/$/, '');
      const res = await fetch(`${cleanUrl}/api/v3/queue`, {
        headers: { 'X-Api-Key': config.apiKey },
        signal: AbortSignal.timeout(4000),
      });
      if (!res.ok) return [];
      const data = await res.json();
      return (data.records || []).map((r: { title: string; size: number; status: string; timeleft?: string }) => ({
        title: r.title,
        size: r.size,
        status: r.status,
        timeleft: r.timeleft,
      }));
    } catch {
      return [];
    }
  }
}

export const sonarrProvider = new ArrProvider('sonarr', 'Sonarr', 8989, 'Automatisierte TV-Serien Verwaltung & Download-Koordination.');
export const radarrProvider = new ArrProvider('radarr', 'Radarr', 7878, 'Automatisierte Film-Sammlung & Download-Koordination.');
export const lidarrProvider = new ArrProvider('lidarr', 'Lidarr', 8686, 'Musikverwaltung und automatische Album-Synchronisation.');
export const prowlarrProvider = new ArrProvider('prowlarr', 'Prowlarr', 9696, 'Index-Manager für Torrent-Tracker und Usenet.');
