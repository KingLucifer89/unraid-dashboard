import { IntegrationProvider, IntegrationConfigData } from '../core/types';

export class HomeAssistantProvider implements IntegrationProvider {
  id = 'homeassistant';
  name = 'Home Assistant';
  type = 'smarthome' as const;
  description = 'Zentrale Smart-Home-Automatisierung für Sensoren, Lampen und Schalter.';
  defaultPort = 8123;

  async connect(config: IntegrationConfigData): Promise<boolean> {
    const res = await this.testConnection(config);
    return res.success;
  }

  async testConnection(config: IntegrationConfigData): Promise<{ success: boolean; message: string; version?: string }> {
    if (!config.url) return { success: false, message: 'Home Assistant URL fehlt.' };
    const cleanUrl = config.url.replace(/\/$/, '');
    try {
      const res = await fetch(`${cleanUrl}/api/`, {
        headers: config.apiKey ? { 'Authorization': `Bearer ${config.apiKey}` } : {},
        signal: AbortSignal.timeout(4000),
      });
      if (res.ok) {
        const data = await res.json();
        return { success: true, message: 'Home Assistant verbunden: ' + (data.message || 'API running'), version: '2024.11' };
      }
      return { success: false, message: `Status: ${res.status}` };
    } catch (err: unknown) {
      return { success: false, message: `Fehler: ${err instanceof Error ? err.message : String(err)}` };
    }
  }
}

export const homeAssistantProvider = new HomeAssistantProvider();
