export interface IntegrationProvider {
  id: string;
  name: string;
  type: 'media' | 'arr' | 'torrent' | 'smarthome' | 'monitoring';
  description: string;
  defaultPort: number;
  connect(config: IntegrationConfigData): Promise<boolean>;
  testConnection(config: IntegrationConfigData): Promise<{ success: boolean; message: string; version?: string }>;
}

export interface IntegrationConfigData {
  url?: string;
  apiKey?: string;
  username?: string;
  password?: string;
  meta?: Record<string, unknown>;
}

export interface MediaSessionData {
  id: string;
  title: string;
  user: string;
  service: string;
  quality: string;
  playbackMode: string;
  progressPercent: number;
  bitrateMbps: number;
  timeRemaining?: string;
  posterUrl?: string;
}
