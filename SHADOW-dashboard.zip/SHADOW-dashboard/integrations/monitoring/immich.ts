import { IntegrationProvider, IntegrationConfigData } from '../core/types';

export class ImmichProvider implements IntegrationProvider {
  id = 'immich';
  name = 'Immich';
  type = 'monitoring' as const;
  description = 'Selbst gehostete High-Performance Foto- und Video-Backup Lösung.';
  defaultPort = 2283;

  async connect(config: IntegrationConfigData): Promise<boolean> {
    const res = await this.testConnection(config);
    return res.success;
  }

  async testConnection(config: IntegrationConfigData): Promise<{ success: boolean; message: string; version?: string }> {
    if (!config.url) return { success: false, message: 'Immich URL fehlt.' };
    const cleanUrl = config.url.replace(/\/$/, '');
    try {
      const res = await fetch(`${cleanUrl}/api/server-info/version`, {
        headers: config.apiKey ? { 'x-api-key': config.apiKey } : {},
        signal: AbortSignal.timeout(4000),
      });
      if (res.ok) {
        const data = await res.json();
        return { success: true, message: 'Immich Server bereit.', version: `${data.major}.${data.minor}.${data.patch}` };
      }
      return { success: false, message: `Status: ${res.status}` };
    } catch (err: unknown) {
      return { success: false, message: `Fehler: ${err instanceof Error ? err.message : String(err)}` };
    }
  }
}

export const immichProvider = new ImmichProvider();
