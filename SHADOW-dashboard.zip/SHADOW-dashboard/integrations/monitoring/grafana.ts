import { IntegrationProvider, IntegrationConfigData } from '../core/types';

export class GrafanaProvider implements IntegrationProvider {
  id = 'grafana';
  name = 'Grafana';
  type = 'monitoring' as const;
  description = 'Analytik- und interaktive Visualisierungsplattform für Servermetriken.';
  defaultPort = 3000;

  async connect(config: IntegrationConfigData): Promise<boolean> {
    const res = await this.testConnection(config);
    return res.success;
  }

  async testConnection(config: IntegrationConfigData): Promise<{ success: boolean; message: string; version?: string }> {
    if (!config.url) return { success: false, message: 'Grafana URL fehlt.' };
    const cleanUrl = config.url.replace(/\/$/, '');
    try {
      const res = await fetch(`${cleanUrl}/api/health`, {
        headers: config.apiKey ? { 'Authorization': `Bearer ${config.apiKey}` } : {},
        signal: AbortSignal.timeout(4000),
      });
      if (res.ok) {
        const data = await res.json();
        return { success: true, message: 'Grafana Service aktiv: ' + (data.database || 'ok'), version: data.version || 'v10.4.1' };
      }
      return { success: false, message: `Status: ${res.status}` };
    } catch (err: unknown) {
      return { success: false, message: `Fehler: ${err instanceof Error ? err.message : String(err)}` };
    }
  }
}

export const grafanaProvider = new GrafanaProvider();
