import { IntegrationProvider } from './core/types';
import { JellyfinProvider } from './media/jellyfin';
import { EmbyProvider } from './media/emby';
import { PlexProvider } from './media/plex';
import { sonarrProvider, radarrProvider, lidarrProvider, prowlarrProvider } from './arr/arr-client';
import { qBittorrentProvider } from './torrent/qbittorrent';
import { homeAssistantProvider } from './smarthome/homeassistant';
import { immichProvider } from './monitoring/immich';
import { grafanaProvider } from './monitoring/grafana';

export const jellyfinProvider = new JellyfinProvider();
export const embyProvider = new EmbyProvider();
export const plexProvider = new PlexProvider();

export const providersRegistry: Record<string, IntegrationProvider> = {
  jellyfin: jellyfinProvider,
  emby: embyProvider,
  plex: plexProvider,
  sonarr: sonarrProvider,
  radarr: radarrProvider,
  lidarr: lidarrProvider,
  prowlarr: prowlarrProvider,
  qbittorrent: qBittorrentProvider,
  homeassistant: homeAssistantProvider,
  immich: immichProvider,
  grafana: grafanaProvider,
};

export function getProvider(id: string): IntegrationProvider | undefined {
  return providersRegistry[id];
}
