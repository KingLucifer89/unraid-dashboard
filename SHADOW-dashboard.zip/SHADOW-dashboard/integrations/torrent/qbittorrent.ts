import { IntegrationProvider, IntegrationConfigData } from '../core/types';

export class QBittorrentProvider implements IntegrationProvider {
  id = 'qbittorrent';
  name = 'qBittorrent';
  type = 'torrent' as const;
  description = 'Open-Source BitTorrent-Client mit WebUI und API-Steuerung.';
  defaultPort = 8080;

  async connect(config: IntegrationConfigData): Promise<boolean> {
    const res = await this.testConnection(config);
    return res.success;
  }

  async testConnection(config: IntegrationConfigData): Promise<{ success: boolean; message: string; version?: string }> {
    if (!config.url) return { success: false, message: 'Server-URL fehlt.' };
    const cleanUrl = config.url.replace(/\/$/, '');
    try {
      const res = await fetch(`${cleanUrl}/api/v2/app/version`, {
        signal: AbortSignal.timeout(4000),
      });
      if (res.ok) {
        const ver = await res.text();
        return { success: true, message: 'qBittorrent API erreichbar.', version: ver || 'v4.6.5' };
      }
      return { success: false, message: `Status: ${res.status}` };
    } catch (err: unknown) {
      return { success: false, message: `Verbindung fehlgeschlagen: ${err instanceof Error ? err.message : String(err)}` };
    }
  }
}

export const qBittorrentProvider = new QBittorrentProvider();
