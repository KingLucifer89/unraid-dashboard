import { IntegrationProvider, IntegrationConfigData, MediaSessionData } from '../core/types';

export class JellyfinProvider implements IntegrationProvider {
  id = 'jellyfin';
  name = 'Jellyfin';
  type = 'media' as const;
  description = 'Open-Source Media Server zur Verwaltung von Filmen, Serien und Musik.';
  defaultPort = 8096;

  async connect(config: IntegrationConfigData): Promise<boolean> {
    const res = await this.testConnection(config);
    return res.success;
  }

  async testConnection(config: IntegrationConfigData): Promise<{ success: boolean; message: string; version?: string }> {
    if (!config.url) {
      return { success: false, message: 'Server-URL fehlt.' };
    }
    const cleanUrl = config.url.replace(/\/$/, '');
    try {
      const res = await fetch(`${cleanUrl}/System/Info/Public`, {
        headers: config.apiKey ? { 'X-Emby-Token': config.apiKey } : {},
        signal: AbortSignal.timeout(4000),
      });
      if (res.ok) {
        const data = await res.json();
        return { success: true, message: 'Verbindung erfolgreich hergestellt.', version: data.Version || 'v10.9.11' };
      }
      return { success: false, message: `Server antwortete mit Status: ${res.status}` };
    } catch (err: unknown) {
      return { success: false, message: `Verbindungsfehler: ${err instanceof Error ? err.message : String(err)}` };
    }
  }

  async getSessions(config: IntegrationConfigData): Promise<MediaSessionData[]> {
    if (!config.url || !config.apiKey) return [];
    try {
      const cleanUrl = config.url.replace(/\/$/, '');
      const res = await fetch(`${cleanUrl}/Sessions`, {
        headers: { 'X-Emby-Token': config.apiKey },
        signal: AbortSignal.timeout(4000),
      });
      if (!res.ok) return [];
      const sessions = await res.json();
      return (sessions || [])
        .filter((s: { NowPlayingItem?: unknown }) => s.NowPlayingItem)
        .map((s: {
          Id: string;
          UserName?: string;
          NowPlayingItem: {
            Name?: string;
            SeriesName?: string;
            SeasonNumber?: number;
            IndexNumber?: number;
            RunTimeTicks?: number;
            Id?: string;
          };
          PlayState?: { PositionTicks?: number; IsPaused?: boolean; PlayMethod?: string };
          TranscodingInfo?: { Bitrate?: number; IsVideoDirect?: boolean; IsAudioDirect?: boolean };
        }) => {
          const item = s.NowPlayingItem;
          const pos = s.PlayState?.PositionTicks || 0;
          const total = item.RunTimeTicks || 1;
          const progress = Math.min(100, Math.round((pos / total) * 100));

          let title = item.Name || 'Unbekanntes Medium';
          if (item.SeriesName) {
            title = `${item.SeriesName} S${item.SeasonNumber || 1}E${item.IndexNumber || 1}`;
          }

          const bitrate = s.TranscodingInfo?.Bitrate 
            ? Math.round(s.TranscodingInfo.Bitrate / 1000000 * 10) / 10 
            : 8.4;

          const isDirect = s.TranscodingInfo ? false : true;

          return {
            id: s.Id,
            title,
            user: s.UserName || 'Anonym',
            service: 'Jellyfin',
            quality: '1080p',
            playbackMode: isDirect ? 'Direct Play' : 'Transcoding',
            progressPercent: progress,
            bitrateMbps: bitrate,
            posterUrl: item.Id ? `${cleanUrl}/Items/${item.Id}/Images/Primary` : undefined,
          };
        });
    } catch {
      return [];
    }
  }
}
