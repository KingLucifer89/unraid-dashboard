import { IntegrationProvider, IntegrationConfigData, MediaSessionData } from '../core/types';

export class PlexProvider implements IntegrationProvider {
  id = 'plex';
  name = 'Plex';
  type = 'media' as const;
  description = 'Plex Media Server für Streaming auf allen Geräten weltweit.';
  defaultPort = 32400;

  async connect(config: IntegrationConfigData): Promise<boolean> {
    const res = await this.testConnection(config);
    return res.success;
  }

  async testConnection(config: IntegrationConfigData): Promise<{ success: boolean; message: string; version?: string }> {
    if (!config.url) return { success: false, message: 'Plex Server-URL fehlt.' };
    const cleanUrl = config.url.replace(/\/$/, '');
    try {
      const headers: Record<string, string> = { 'Accept': 'application/json' };
      if (config.apiKey) headers['X-Plex-Token'] = config.apiKey;
      const res = await fetch(`${cleanUrl}/identity`, { headers, signal: AbortSignal.timeout(4000) });
      if (res.ok) {
        const data = await res.json();
        return { success: true, message: 'Plex Media Server erreichbar.', version: data?.MediaContainer?.version || 'v1.40.1' };
      }
      return { success: false, message: `Plex Statusfehler: ${res.status}` };
    } catch (err: unknown) {
      return { success: false, message: `Verbindung fehlgeschlagen: ${err instanceof Error ? err.message : String(err)}` };
    }
  }

  async getSessions(config: IntegrationConfigData): Promise<MediaSessionData[]> {
    if (!config.url || !config.apiKey) return [];
    try {
      const cleanUrl = config.url.replace(/\/$/, '');
      const res = await fetch(`${cleanUrl}/status/sessions`, {
        headers: { 'Accept': 'application/json', 'X-Plex-Token': config.apiKey },
        signal: AbortSignal.timeout(4000),
      });
      if (!res.ok) return [];
      const data = await res.json();
      const metadata = data?.MediaContainer?.Metadata || [];
      return metadata.map((m: {
        sessionKey: string;
        title: string;
        grandparentTitle?: string;
        parentIndex?: number;
        index?: number;
        User?: { title?: string };
        viewOffset?: number;
        duration?: number;
        TranscodeSession?: { videoDecision?: string; audioDecision?: string; progress?: number };
      }) => {
        let title = m.title;
        if (m.grandparentTitle) {
          title = `${m.grandparentTitle} S${m.parentIndex}E${m.index}`;
        }
        const offset = m.viewOffset || 0;
        const dur = m.duration || 1;
        const isTranscode = !!m.TranscodeSession;

        return {
          id: m.sessionKey || Math.random().toString(),
          title,
          user: m.User?.title || 'Plex User',
          service: 'Plex',
          quality: '1080p',
          playbackMode: isTranscode ? 'Transcoding' : 'Direct Play',
          progressPercent: Math.min(100, Math.round((offset / dur) * 100)),
          bitrateMbps: 12.6,
        };
      });
    } catch {
      return [];
    }
  }
}
