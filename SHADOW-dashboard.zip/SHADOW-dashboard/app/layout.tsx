import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'SHADOW · Unraid Dashboard',
  description: 'Cyberpunk Red Neon Next.js Self-Hosted Unraid Server Control Center & Homarr Alternative',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="de" className="dark">
      <body className="bg-[#060608] text-gray-100 min-h-screen antialiased selection:bg-red-600 selection:text-white">
        {children}
      </body>
    </html>
  );
}
