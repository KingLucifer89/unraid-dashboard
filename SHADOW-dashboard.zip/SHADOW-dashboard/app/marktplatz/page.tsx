'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/navigation/Sidebar';
import { Header } from '@/components/navigation/Header';
import { MarketplaceSidebar } from '@/components/marketplace/MarketplaceSidebar';
import { Store } from 'lucide-react';

export default function MarktplatzPage() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen flex bg-[#060608]">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${collapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <Header editMode={false} setEditMode={() => {}} onOpenAddWidget={() => {}} setMobileOpen={setMobileOpen} />

        <main className="flex-1 p-4 lg:p-6 space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <Store className="text-shadow-red" />
              Plugin & Docker Marktplatz
            </h2>
            <p className="text-xs text-gray-400">
              Durchsuche Docker Hub Container, Community-Vorlagen und SHADOW-Integrationen
            </p>
          </div>

          <div className="max-w-2xl">
            <MarketplaceSidebar />
          </div>
        </main>
      </div>
    </div>
  );
}
