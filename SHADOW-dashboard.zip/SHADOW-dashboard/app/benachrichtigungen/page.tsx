'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/navigation/Sidebar';
import { Header } from '@/components/navigation/Header';
import { Bell, Check, Trash2 } from 'lucide-react';

export default function BenachrichtigungenPage() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const notifications = [
    { id: '1', title: 'Unraid Status OK', message: 'Alle Festplatten im Array sind fehlerfrei.', time: 'Vor 5 Minuten', level: 'success' },
    { id: '2', title: 'Docker Container aktiv', message: '12 von 18 Containern laufen einwandfrei.', time: 'Vor 15 Minuten', level: 'info' },
    { id: '3', title: 'Jellyfin Transkodierung', message: 'Breaking Bad Stream erfordert HW-Transkodierung.', time: 'Vor 32 Minuten', level: 'info' },
  ];

  return (
    <div className="min-h-screen flex bg-[#060608]">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${collapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <Header editMode={false} setEditMode={() => {}} onOpenAddWidget={() => {}} setMobileOpen={setMobileOpen} />

        <main className="flex-1 p-4 lg:p-6 space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <Bell className="text-shadow-red" />
              Benachrichtigungszentrale
            </h2>
            <p className="text-xs text-gray-400">
              Systemhinweise, Warnungen und API-Ereignisse im Überblick
            </p>
          </div>

          <div className="space-y-3 max-w-2xl">
            {notifications.map((n) => (
              <div key={n.id} className="glass-panel p-4 rounded-2xl border border-white/10 flex items-start justify-between gap-4">
                <div>
                  <h4 className="text-xs font-bold text-white mb-1">{n.title}</h4>
                  <p className="text-xs text-gray-400">{n.message}</p>
                  <span className="text-[10px] text-gray-500 mt-2 block">{n.time}</span>
                </div>
                <button className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white">
                  <Check size={14} />
                </button>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
