'use client';

import React, { useState, useEffect } from 'react';
import { Sidebar } from '@/components/navigation/Sidebar';
import { Header } from '@/components/navigation/Header';
import { FileText, Search, RefreshCw, AlertTriangle, Info } from 'lucide-react';

export default function LogsPage() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [logs, setLogs] = useState<Array<{ id: string; timestamp: string; level: string; source: string; message: string }>>([]);
  const [search, setSearch] = useState('');

  const fetchLogs = async () => {
    try {
      const res = await fetch('/api/logs');
      if (res.ok) {
        const d = await res.json();
        setLogs(d.logs || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const filtered = logs.filter(l =>
    l.message.toLowerCase().includes(search.toLowerCase()) ||
    l.source.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen flex bg-[#060608]">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${collapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <Header editMode={false} setEditMode={() => {}} onOpenAddWidget={() => {}} setMobileOpen={setMobileOpen} />

        <main className="flex-1 p-4 lg:p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                <FileText className="text-shadow-red" />
                System- & Anwendungs-Logs
              </h2>
              <p className="text-xs text-gray-400">
                Zentrales Audit-Logbuch für Docker-Events, API-Anfragen und Systemwarnungen
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <Search size={14} className="absolute left-3 top-2.5 text-gray-500" />
                <input
                  type="text"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Logs durchsuchen ..."
                  className="bg-[#101017] border border-white/10 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white"
                />
              </div>
              <button onClick={fetchLogs} className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white">
                <RefreshCw size={14} />
              </button>
            </div>
          </div>

          <div className="glass-panel rounded-2xl overflow-hidden border border-[#ff1a35]/20 p-4 font-mono text-xs">
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {filtered.map(l => (
                <div key={l.id} className="p-2.5 bg-black/50 rounded-xl border border-white/5 flex items-start gap-3">
                  <span className="text-gray-500 text-[10px] whitespace-nowrap mt-0.5">
                    {new Date(l.timestamp).toLocaleTimeString('de-DE')}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                    l.level === 'warning' ? 'bg-amber-950 text-amber-400' : 'bg-red-950 text-red-400'
                  }`}>
                    {l.source}
                  </span>
                  <span className="text-gray-300 flex-1">{l.message}</span>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
