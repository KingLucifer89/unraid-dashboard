'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/navigation/Sidebar';
import { Header } from '@/components/navigation/Header';
import { ShieldCheck, Download, Upload, AlertCircle } from 'lucide-react';

export default function BackupPage() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen flex bg-[#060608]">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${collapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <Header editMode={false} setEditMode={() => {}} onOpenAddWidget={() => {}} setMobileOpen={setMobileOpen} />

        <main className="flex-1 p-4 lg:p-6 space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <ShieldCheck className="text-shadow-red" />
              Backup & Konfigurations-Export
            </h2>
            <p className="text-xs text-gray-400">
              Sichere Dashboard-Layouts, installierte Widgets, App-Verknüpfungen und API-Profile
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl">
            <div className="glass-panel p-6 rounded-2xl border border-white/10 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold text-white mb-2">Konfiguration exportieren</h3>
                <p className="text-xs text-gray-400 mb-4">
                  Erstelle einen portablen JSON-Snapshot deines Dashboards. Sensible Passwörter und API-Keys werden serverseitig maskiert.
                </p>
              </div>
              <a
                href="/api/backup"
                download="shadow-backup.json"
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-xs shadow-neon-red"
              >
                <Download size={14} />
                Snapshot herunterladen (.json)
              </a>
            </div>

            <div className="glass-panel p-6 rounded-2xl border border-white/10 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold text-white mb-2">Konfiguration wiederherstellen</h3>
                <p className="text-xs text-gray-400 mb-4">
                  Lade ein zuvor gesichertes JSON-Backup hoch, um dein Dashboard und deine Apps sofort wiederherzustellen.
                </p>
              </div>
              <button
                onClick={() => alert('Wiederherstellung: Bitte die Datei in /data/shadow.db einbinden oder über das Web-UI importieren.')}
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs border border-white/10"
              >
                <Upload size={14} />
                Backup hochladen
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
