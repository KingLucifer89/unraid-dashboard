'use client';

import React, { useState, useEffect } from 'react';
import { Sidebar } from '@/components/navigation/Sidebar';
import { Header } from '@/components/navigation/Header';
import { AppItemDto } from '@/types';
import { Layers, Plus, ExternalLink, Trash2, Edit3, CheckCircle, Globe } from 'lucide-react';

export default function AppsPage() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [apps, setApps] = useState<AppItemDto[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newApp, setNewApp] = useState({ name: '', url: '', category: 'Tools', description: '', color: '#ff1a35' });

  const fetchApps = async () => {
    try {
      const res = await fetch('/api/apps');
      if (res.ok) {
        const data = await res.json();
        setApps(data.apps || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchApps();
  }, []);

  const handleCreateApp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newApp.name || !newApp.url) return;
    try {
      const res = await fetch('/api/apps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newApp),
      });
      if (res.ok) {
        setShowAddModal(false);
        setNewApp({ name: '', url: '', category: 'Tools', description: '', color: '#ff1a35' });
        fetchApps();
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen flex bg-[#060608]">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${collapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <Header editMode={false} setEditMode={() => {}} onOpenAddWidget={() => {}} setMobileOpen={setMobileOpen} />

        <main className="flex-1 p-4 lg:p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                <Layers className="text-shadow-red" />
                Anwendungen & Dienste
              </h2>
              <p className="text-xs text-gray-400">
                Verwalte deine selbst gehosteten Web-Oberflächen, Dashboards und Tools
              </p>
            </div>

            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-red-600 hover:bg-red-500 text-white shadow-neon-red"
            >
              <Plus size={15} />
              Neue App hinzufügen
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {apps.map((app) => (
              <div
                key={app.id}
                className="glass-panel rounded-2xl p-4 border border-white/10 hover:border-red-500/40 transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-white text-base shadow-md"
                      style={{ backgroundColor: `${app.color || '#ff1a35'}25`, border: `1px solid ${app.color || '#ff1a35'}60` }}
                    >
                      <Globe size={18} style={{ color: app.color || '#ff1a35' }} />
                    </div>
                    <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-medium">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      Online
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white group-hover:text-red-400 transition-colors">
                    {app.name}
                  </h3>
                  <p className="text-[10px] text-gray-400 font-medium uppercase tracking-wider mb-2">
                    {app.category}
                  </p>
                  <p className="text-xs text-gray-400 line-clamp-2">
                    {app.description || 'Keine Beschreibung hinterlegt.'}
                  </p>
                </div>

                <div className="pt-3 mt-3 border-t border-white/5 flex items-center justify-between">
                  <span className="text-[10px] text-gray-500 font-mono truncate max-w-[140px]">
                    {app.url}
                  </span>
                  <a
                    href={app.url}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1.5 rounded-lg bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white transition-all flex items-center gap-1 text-[11px] font-semibold"
                  >
                    <span>Öffnen</span>
                    <ExternalLink size={12} />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <form onSubmit={handleCreateApp} className="w-full max-w-md bg-[#0e0e14] border border-red-500/40 rounded-2xl shadow-neon-red-lg p-6 space-y-4">
            <h3 className="text-base font-bold text-white">Neue Anwendung verlinken</h3>
            <div>
              <label className="text-xs text-gray-300 block mb-1">Name</label>
              <input
                required
                value={newApp.name}
                onChange={e => setNewApp({ ...newApp, name: e.target.value })}
                placeholder="z.B. Portainer"
                className="w-full bg-[#101017] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-gray-300 block mb-1">URL</label>
              <input
                required
                value={newApp.url}
                onChange={e => setNewApp({ ...newApp, url: e.target.value })}
                placeholder="http://192.168.178.10:9000"
                className="w-full bg-[#101017] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-gray-300 block mb-1">Kategorie</label>
              <input
                value={newApp.category}
                onChange={e => setNewApp({ ...newApp, category: e.target.value })}
                placeholder="Tools / Media / System"
                className="w-full bg-[#101017] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs text-gray-300 block mb-1">Beschreibung</label>
              <input
                value={newApp.description}
                onChange={e => setNewApp({ ...newApp, description: e.target.value })}
                placeholder="Kurze Beschreibung"
                className="w-full bg-[#101017] border border-white/10 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-3 py-1.5 rounded-xl text-xs bg-white/10 text-white"
              >
                Abbrechen
              </button>
              <button
                type="submit"
                className="px-3 py-1.5 rounded-xl text-xs bg-red-600 hover:bg-red-500 text-white shadow-neon-red font-semibold"
              >
                Speichern
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
