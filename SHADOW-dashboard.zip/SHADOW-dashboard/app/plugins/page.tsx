'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/navigation/Sidebar';
import { Header } from '@/components/navigation/Header';
import { Puzzle, ShieldCheck, CheckCircle2, Plus } from 'lucide-react';

export default function PluginsPage() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const plugins = [
    { id: 'com.shadow.jellyfin', name: 'Jellyfin Connector', version: '1.2.0', author: 'SHADOW Team', desc: 'Liest aktive Streams und Bibliotheksstatistiken aus.', permissions: ['api.external', 'notifications.write'], enabled: true },
    { id: 'com.shadow.unraid-sensors', name: 'Unraid Hardware Sensors', version: '2.0.4', author: 'Unraid Community', desc: 'Erfasst Festplattentemperaturen und CPU Lüfterdrehzahlen.', permissions: ['system.read'], enabled: true },
    { id: 'com.shadow.docker-watcher', name: 'Docker Auto-Watcher', version: '1.0.1', author: 'SHADOW Team', desc: 'Überwacht Container-Crashes und meldet Statusänderungen.', permissions: ['docker.read', 'docker.manage'], enabled: true },
    { id: 'com.shadow.sonarr-sync', name: 'ARR Media Pipeline', version: '1.1.0', author: 'Community', desc: 'Synchronisiert Sonarr & Radarr Download-Warteschlangen.', permissions: ['api.external'], enabled: true },
  ];

  return (
    <div className="min-h-screen flex bg-[#060608]">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${collapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <Header editMode={false} setEditMode={() => {}} onOpenAddWidget={() => {}} setMobileOpen={setMobileOpen} />

        <main className="flex-1 p-4 lg:p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                <Puzzle className="text-shadow-red" />
                Installierte SHADOW Plugins
              </h2>
              <p className="text-xs text-gray-400">
                Erweiterbare Plugin-Architektur für Drittanbieter-Widgets, Sensoren und API-Treiber
              </p>
            </div>
            <a
              href="/marktplatz"
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-red-600 hover:bg-red-500 text-white shadow-neon-red flex items-center gap-1.5"
            >
              <Plus size={15} />
              Neues Plugin installieren
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {plugins.map((p) => (
              <div key={p.id} className="glass-panel p-4 rounded-2xl border border-white/10 hover:border-red-500/30 transition-all flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-bold text-white">{p.name}</h3>
                    <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/20 flex items-center gap-1">
                      <CheckCircle2 size={10} /> Aktiv
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 mb-3">{p.desc}</p>
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {p.permissions.map((perm, i) => (
                      <span key={i} className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 border border-white/10 text-gray-300">
                        {perm}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-gray-500 font-mono">
                  <span>v{p.version} · {p.author}</span>
                  <span className="text-red-400 hover:underline cursor-pointer">Konfigurieren</span>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
