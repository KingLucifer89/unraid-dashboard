import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const layout = await prisma.dashboardLayout.findFirst({ where: { isDefault: true } });
    const apps = await prisma.appItem.findMany();
    const integrations = await prisma.integrationConfig.findMany({
      select: {
        id: true,
        name: true,
        type: true,
        url: true,
        enabled: true,
        lastStatus: true,
      }
    });

    const exportPayload = {
      app: 'SHADOW UNRAID DASHBOARD',
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      layout: layout ? JSON.parse(layout.layoutJson) : null,
      apps,
      integrations,
    };

    return new NextResponse(JSON.stringify(exportPayload, null, 2), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': 'attachment; filename="shadow-backup.json"',
      }
    });
  } catch (err: unknown) {
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
