import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { DEFAULT_LAYOUT } from '@/lib/default-data';
import { ensureDatabaseInitialized } from '@/lib/db-init';

export async function GET() {
  try {
    await ensureDatabaseInitialized();
    const layout = await prisma.dashboardLayout.findUnique({
      where: { id: 'default' }
    });

    if (!layout) {
      return NextResponse.json({ layout: DEFAULT_LAYOUT });
    }

    try {
      const parsed = JSON.parse(layout.layoutJson);
      return NextResponse.json({ layout: parsed });
    } catch {
      return NextResponse.json({ layout: DEFAULT_LAYOUT });
    }
  } catch (err: unknown) {
    return NextResponse.json({ layout: DEFAULT_LAYOUT, error: String(err) });
  }
}

export async function POST(req: Request) {
  try {
    const { layout } = await req.json();
    if (!layout || !Array.isArray(layout)) {
      return NextResponse.json({ error: 'Ungültiges Layout-Format' }, { status: 400 });
    }

    await prisma.dashboardLayout.upsert({
      where: { id: 'default' },
      update: {
        layoutJson: JSON.stringify(layout),
        updatedAt: new Date(),
      },
      create: {
        id: 'default',
        name: 'Standard Layout',
        layoutJson: JSON.stringify(layout),
        isDefault: true,
      }
    });

    return NextResponse.json({ success: true, message: 'Dashboard Layout gespeichert.' });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Fehler beim Speichern' }, { status: 500 });
  }
}
