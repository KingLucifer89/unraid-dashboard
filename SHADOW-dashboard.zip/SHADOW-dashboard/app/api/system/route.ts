import { NextResponse } from 'next/server';
import { getSystemStats } from '@/server/system/system-stats';

export async function GET() {
  try {
    const stats = getSystemStats();
    return NextResponse.json(stats);
  } catch (err: unknown) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'Systemstatistiken konnten nicht geladen werden.' },
      { status: 500 }
    );
  }
}
