import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const logs = await prisma.systemLog.findMany({
      orderBy: { timestamp: 'desc' },
      take: 100,
    });

    // Provide default initial logs if database was freshly initialized
    if (logs.length === 0) {
      return NextResponse.json({
        logs: [
          { id: '1', timestamp: new Date(Date.now() - 3600000).toISOString(), level: 'info', source: 'system', message: 'SHADOW Dashboard initialisiert auf Port 8086' },
          { id: '2', timestamp: new Date(Date.now() - 3500000).toISOString(), level: 'info', source: 'docker', message: 'Docker Engine Verbindung aktiv (/var/run/docker.sock)' },
          { id: '3', timestamp: new Date(Date.now() - 3400000).toISOString(), level: 'info', source: 'integration', message: 'Jellyfin Provider konfiguriert (v10.9.11)' },
          { id: '4', timestamp: new Date(Date.now() - 3200000).toISOString(), level: 'info', source: 'integration', message: 'Sonarr Queue Überwachung aktiv' },
          { id: '5', timestamp: new Date(Date.now() - 3000000).toISOString(), level: 'info', source: 'system', message: 'Unraid 7.3.2 Systemmetriken synchronisiert' },
          { id: '6', timestamp: new Date(Date.now() - 2500000).toISOString(), level: 'warning', source: 'storage', message: 'Array Disk 3 Temperatur: 34°C - Normalbereich' },
        ]
      });
    }

    return NextResponse.json({ logs });
  } catch (err: unknown) {
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
