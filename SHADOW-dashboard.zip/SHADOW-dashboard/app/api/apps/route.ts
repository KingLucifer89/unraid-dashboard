import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { ensureDatabaseInitialized } from '@/lib/db-init';
import { DEFAULT_APPS } from '@/lib/default-data';

export async function GET() {
  try {
    await ensureDatabaseInitialized();
    const apps = await prisma.appItem.findMany({
      orderBy: { order: 'asc' }
    });

    return NextResponse.json({ apps: apps.length > 0 ? apps : DEFAULT_APPS });
  } catch {
    return NextResponse.json({ apps: DEFAULT_APPS });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, url, category, description, color, openNewTab, icon } = body;

    if (!name || !url) {
      return NextResponse.json({ error: 'Name und URL sind erforderlich.' }, { status: 400 });
    }

    const app = await prisma.appItem.create({
      data: {
        name,
        url,
        category: category || 'Apps',
        description: description || '',
        color: color || '#ff1a35',
        openNewTab: openNewTab ?? true,
        icon: icon || 'grid',
        status: 'online',
        order: 99,
      }
    });

    return NextResponse.json({ success: true, app });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Fehler' }, { status: 500 });
  }
}
