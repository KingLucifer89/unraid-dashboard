import { NextResponse } from 'next/server';
import { dockerClient } from '@/server/docker/docker-client';
import { prisma } from '@/lib/prisma';

export async function POST(req: Request) {
  try {
    const { action, containerId, containerName } = await req.json();

    if (!action || !containerId) {
      return NextResponse.json({ error: 'Aktion und Container-ID sind erforderlich.' }, { status: 400 });
    }

    if (dockerClient.isAvailable()) {
      switch (action) {
        case 'start':
          await dockerClient.startContainer(containerId);
          break;
        case 'stop':
          await dockerClient.stopContainer(containerId);
          break;
        case 'restart':
          await dockerClient.restartContainer(containerId);
          break;
        case 'pause':
          await dockerClient.pauseContainer(containerId);
          break;
        case 'unpause':
          await dockerClient.unpauseContainer(containerId);
          break;
        default:
          return NextResponse.json({ error: `Unbekannte Aktion: ${action}` }, { status: 400 });
      }
    }

    // Log action in audit log
    await prisma.systemLog.create({
      data: {
        level: 'info',
        source: 'docker',
        message: `Container ${containerName || containerId}: Aktion '${action}' ausgeführt.`,
        details: JSON.stringify({ action, containerId, timestamp: new Date() }),
      }
    });

    return NextResponse.json({ success: true, message: `Aktion ${action} für ${containerName || containerId} ausgeführt.` });
  } catch (err: unknown) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'Docker-Aktion fehlgeschlagen.' },
      { status: 500 }
    );
  }
}
