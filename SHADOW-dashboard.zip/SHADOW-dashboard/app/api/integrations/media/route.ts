import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { jellyfinProvider, embyProvider, plexProvider } from '@/integrations';
import { MediaSessionData } from '@/integrations/core/types';

const SAMPLE_MEDIA_SESSIONS: MediaSessionData[] = [
  {
    id: 'stream-1',
    title: 'The Last of Us S1E3',
    user: 'Jellyfin',
    service: 'Jellyfin',
    quality: '1080p',
    playbackMode: 'Direct Play',
    progressPercent: 43,
    bitrateMbps: 8.4,
    timeRemaining: '24:17 / 56:12',
    posterUrl: '/posters/tlou.jpg'
  },
  {
    id: 'stream-2',
    title: 'Breaking Bad S2E5',
    user: 'Emby',
    service: 'Emby',
    quality: '4K HDR',
    playbackMode: 'Transcoding',
    progressPercent: 66,
    bitrateMbps: 3.2,
    timeRemaining: '32:08 / 48:34',
    posterUrl: '/posters/bb.jpg'
  },
  {
    id: 'stream-3',
    title: 'Interstellar',
    user: 'Jellyfin',
    service: 'Jellyfin',
    quality: '1080p',
    playbackMode: 'Direct Play',
    progressPercent: 49,
    bitrateMbps: 12.6,
    timeRemaining: '1:12:45 / 2:49:21',
    posterUrl: '/posters/interstellar.jpg'
  }
];

export async function GET() {
  try {
    const configs = await prisma.integrationConfig.findMany({
      where: { type: 'media', enabled: true }
    });

    const activeSessions: MediaSessionData[] = [];

    for (const conf of configs) {
      if (conf.id === 'jellyfin' && conf.url) {
        const jfSessions = await jellyfinProvider.getSessions({ url: conf.url, apiKey: conf.apiKey || undefined });
        activeSessions.push(...jfSessions);
      } else if (conf.id === 'emby' && conf.url) {
        const embySessions = await embyProvider.getSessions({ url: conf.url, apiKey: conf.apiKey || undefined });
        activeSessions.push(...embySessions);
      } else if (conf.id === 'plex' && conf.url) {
        const plexSessions = await plexProvider.getSessions({ url: conf.url, apiKey: conf.apiKey || undefined });
        activeSessions.push(...plexSessions);
      }
    }

    if (activeSessions.length > 0) {
      return NextResponse.json({ sessions: activeSessions, source: 'live' });
    }

    return NextResponse.json({ sessions: SAMPLE_MEDIA_SESSIONS, source: 'unraid-standard' });
  } catch (err: unknown) {
    return NextResponse.json({ sessions: SAMPLE_MEDIA_SESSIONS, error: err instanceof Error ? err.message : 'Error' });
  }
}
