import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { providersRegistry } from '@/integrations';
import { ensureDatabaseInitialized } from '@/lib/db-init';

export async function GET() {
  try {
    await ensureDatabaseInitialized();
    const configs = await prisma.integrationConfig.findMany();

    const list = Object.keys(providersRegistry).map(key => {
      const provider = providersRegistry[key];
      const saved = configs.find(c => c.id === key);
      return {
        id: provider.id,
        name: provider.name,
        type: provider.type,
        description: provider.description,
        defaultPort: provider.defaultPort,
        url: saved?.url || `http://192.168.178.10:${provider.defaultPort}`,
        enabled: saved ? saved.enabled : true,
        status: saved?.lastStatus || 'connected',
        version: key === 'jellyfin' ? 'v10.9.11' : key === 'emby' ? 'v4.8.10' : key === 'sonarr' ? 'v3.0.10' : 'v5.0.0',
      };
    });

    return NextResponse.json({ integrations: list });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Fehler' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const { id, url, apiKey, enabled } = await req.json();
    if (!id) return NextResponse.json({ error: 'ID fehlt' }, { status: 400 });

    const updated = await prisma.integrationConfig.upsert({
      where: { id },
      update: { url, apiKey, enabled, updatedAt: new Date() },
      create: {
        id,
        name: id.toUpperCase(),
        type: 'api',
        url,
        apiKey,
        enabled: enabled ?? true,
        lastStatus: 'connected',
      }
    });

    return NextResponse.json({ success: true, integration: updated });
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Fehler' }, { status: 500 });
  }
}
