import { NextResponse } from 'next/server';
import { MARKETPLACE_ITEMS } from '@/lib/default-data';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get('q')?.toLowerCase() || '';
  const category = searchParams.get('category') || 'Alle';
  const tab = searchParams.get('tab') || 'Docker.io';

  let filtered = MARKETPLACE_ITEMS;

  if (tab === 'Docker.io') {
    filtered = filtered.filter(i => i.source === 'docker.io');
  } else if (tab === 'Community') {
    filtered = filtered.filter(i => i.source === 'community');
  }

  if (category !== 'Alle') {
    filtered = filtered.filter(i => i.category.toLowerCase() === category.toLowerCase());
  }

  if (q) {
    filtered = filtered.filter(i => 
      i.name.toLowerCase().includes(q) || 
      i.description.toLowerCase().includes(q) ||
      i.category.toLowerCase().includes(q)
    );
  }

  return NextResponse.json({ items: filtered });
}
