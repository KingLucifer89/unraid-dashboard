import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const notifications = await prisma.notification.findMany({
      orderBy: { timestamp: 'desc' },
      take: 20,
    });
    return NextResponse.json({ notifications });
  } catch (err: unknown) {
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const { id, markAllRead } = await req.json();
    if (markAllRead) {
      await prisma.notification.updateMany({
        where: { read: false },
        data: { read: true }
      });
      return NextResponse.json({ success: true });
    }
    if (id) {
      await prisma.notification.update({
        where: { id },
        data: { read: true }
      });
      return NextResponse.json({ success: true });
    }
    return NextResponse.json({ error: 'Aktion nicht angegeben' }, { status: 400 });
  } catch (err: unknown) {
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
