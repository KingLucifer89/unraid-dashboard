'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/navigation/Sidebar';
import { Header } from '@/components/navigation/Header';
import { DashboardGrid } from '@/components/dashboard/DashboardGrid';

export default function HomePage() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [openAddModal, setOpenAddModal] = useState(false);

  return (
    <div className="min-h-screen flex bg-[#060608]">
      {/* Sidebar Navigation */}
      <Sidebar
        collapsed={collapsed}
        setCollapsed={setCollapsed}
        mobileOpen={mobileOpen}
        setMobileOpen={setMobileOpen}
      />

      {/* Main Content Area */}
      <div
        className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${
          collapsed ? 'lg:pl-20' : 'lg:pl-64'
        }`}
      >
        {/* Header Bar */}
        <Header
          editMode={editMode}
          setEditMode={setEditMode}
          onOpenAddWidget={() => setOpenAddModal(true)}
          setMobileOpen={setMobileOpen}
        />

        {/* Dashboard Grid View */}
        <main className="flex-1 p-4 lg:p-6">
          <DashboardGrid
            editMode={editMode}
            setEditMode={setEditMode}
            openAddModal={openAddModal}
            setOpenAddModal={setOpenAddModal}
          />
        </main>
      </div>
    </div>
  );
}
