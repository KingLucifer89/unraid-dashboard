'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/navigation/Sidebar';
import { Header } from '@/components/navigation/Header';
import { Settings, Save, Server, Shield, Palette } from 'lucide-react';

export default function EinstellungenPage() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [serverName, setServerName] = useState('Unraid Main Server');
  const [savedMsg, setSavedMsg] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedMsg(true);
    setTimeout(() => setSavedMsg(false), 3000);
  };

  return (
    <div className="min-h-screen flex bg-[#060608]">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${collapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <Header editMode={false} setEditMode={() => {}} onOpenAddWidget={() => {}} setMobileOpen={setMobileOpen} />

        <main className="flex-1 p-4 lg:p-6 space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <Settings className="text-shadow-red" />
              SHADOW Einstellungen
            </h2>
            <p className="text-xs text-gray-400">
              Konfiguration von Server-Metadaten, Farbschema, Docker-Socket und Systemsicherheit
            </p>
          </div>

          <form onSubmit={handleSave} className="glass-panel p-6 rounded-2xl border border-white/10 max-w-2xl space-y-5">
            <div>
              <label className="text-xs font-semibold text-gray-300 block mb-1">Server Name</label>
              <input
                type="text"
                value={serverName}
                onChange={e => setServerName(e.target.value)}
                className="w-full bg-[#101017] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-300 block mb-1">Docker Socket Pfad</label>
              <input
                type="text"
                defaultValue="/var/run/docker.sock"
                className="w-full bg-[#101017] border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white font-mono"
              />
              <span className="text-[10px] text-gray-500 mt-1 block">
                Standard Unraid Pfad: /var/run/docker.sock
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-300 block mb-1">Standard Farbschema</label>
              <div className="p-3 bg-black/40 rounded-xl border border-white/5 flex items-center gap-3">
                <div className="w-5 h-5 rounded-full bg-red-600 shadow-neon-red"></div>
                <span className="text-xs font-bold text-white">SHADOW Cyberpunk Neon Red (Aktiv)</span>
              </div>
            </div>

            <div className="pt-3 border-t border-white/10 flex items-center justify-between">
              {savedMsg ? (
                <span className="text-xs text-emerald-400 font-semibold">Einstellungen erfolgreich gespeichert!</span>
              ) : <span></span>}
              <button
                type="submit"
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-red-600 hover:bg-red-500 text-white shadow-neon-red flex items-center gap-2"
              >
                <Save size={14} />
                Änderungen sichern
              </button>
            </div>
          </form>
        </main>
      </div>
    </div>
  );
}
