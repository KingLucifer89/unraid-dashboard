'use client';

import React, { useState, useEffect } from 'react';
import { Sidebar } from '@/components/navigation/Sidebar';
import { Header } from '@/components/navigation/Header';
import { Network, ArrowDown, ArrowUp, Activity, ShieldCheck } from 'lucide-react';
import { SystemStats } from '@/types';

export default function NetzwerkPage() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [stats, setStats] = useState<SystemStats | null>(null);

  useEffect(() => {
    fetch('/api/system').then(r => r.json()).then(d => setStats(d)).catch(console.error);
  }, []);

  return (
    <div className="min-h-screen flex bg-[#060608]">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${collapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <Header editMode={false} setEditMode={() => {}} onOpenAddWidget={() => {}} setMobileOpen={setMobileOpen} />

        <main className="flex-1 p-4 lg:p-6 space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <Network className="text-shadow-red" />
              Netzwerk & Bandbreitenüberwachung
            </h2>
            <p className="text-xs text-gray-400">
              Echtzeit-Durchsatz, Schnittstellen und Übertragungsstatistiken
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="glass-panel p-5 rounded-2xl border border-white/10 flex items-center justify-between">
              <div>
                <span className="text-xs text-gray-400 font-semibold uppercase">Aktueller Download</span>
                <div className="text-3xl font-black text-sky-400 mt-2 font-mono flex items-center gap-2">
                  <ArrowDown size={24} /> 12.4 MB/s
                </div>
                <p className="text-xs text-gray-400 mt-1">Interface: eth0 (Bonding 802.3ad)</p>
              </div>
            </div>

            <div className="glass-panel p-5 rounded-2xl border border-white/10 flex items-center justify-between">
              <div>
                <span className="text-xs text-gray-400 font-semibold uppercase">Aktueller Upload</span>
                <div className="text-3xl font-black text-red-400 mt-2 font-mono flex items-center gap-2">
                  <ArrowUp size={24} /> 6.8 MB/s
                </div>
                <p className="text-xs text-gray-400 mt-1">Verbindung: 1 Gbps Full-Duplex</p>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
