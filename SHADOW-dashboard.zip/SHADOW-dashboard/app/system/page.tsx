'use client';

import React, { useState, useEffect } from 'react';
import { Sidebar } from '@/components/navigation/Sidebar';
import { Header } from '@/components/navigation/Header';
import { SystemStats } from '@/types';
import { Cpu, HardDrive, Network, Clock, ShieldCheck, Thermometer } from 'lucide-react';

export default function SystemPage() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [stats, setStats] = useState<SystemStats | null>(null);

  useEffect(() => {
    fetch('/api/system')
      .then(r => r.json())
      .then(d => setStats(d))
      .catch(console.error);
  }, []);

  return (
    <div className="min-h-screen flex bg-[#060608]">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${collapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <Header editMode={false} setEditMode={() => {}} onOpenAddWidget={() => {}} setMobileOpen={setMobileOpen} />

        <main className="flex-1 p-4 lg:p-6 space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <Cpu className="text-shadow-red" />
              System- und Servermetriken
            </h2>
            <p className="text-xs text-gray-400">
              Host-Hardware, CPU-Last, Speicherauslastung und Betriebszeiten des Unraid-Systems
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="glass-panel p-5 rounded-2xl border border-white/10">
              <span className="text-xs text-gray-400 font-semibold uppercase">Prozessor (CPU)</span>
              <div className="text-3xl font-black text-white mt-2">{stats?.cpu.usagePercent || 12}%</div>
              <p className="text-xs text-red-400 mt-1 font-mono">{stats?.cpu.model || 'Intel Core i9 / AMD EPYC'}</p>
              <div className="mt-4 pt-3 border-t border-white/5 text-xs text-gray-400 flex justify-between">
                <span>Kerne: {stats?.cpu.cores || 8}</span>
                <span>Load: {stats?.cpu.loadAverage.join(', ')}</span>
              </div>
            </div>

            <div className="glass-panel p-5 rounded-2xl border border-white/10">
              <span className="text-xs text-gray-400 font-semibold uppercase">Arbeitsspeicher (RAM)</span>
              <div className="text-3xl font-black text-white mt-2">{stats?.ram.usagePercent || 38}%</div>
              <p className="text-xs text-sky-400 mt-1 font-mono">
                {((stats?.ram.usedBytes || 7.6 * 1024**3) / 1024**3).toFixed(1)} GB / {((stats?.ram.totalBytes || 20 * 1024**3) / 1024**3).toFixed(0)} GB
              </p>
              <div className="mt-4 pt-3 border-t border-white/5 text-xs text-gray-400 flex justify-between">
                <span>Frei: {((stats?.ram.freeBytes || 12.4 * 1024**3) / 1024**3).toFixed(1)} GB</span>
                <span>ECC Status: OK</span>
              </div>
            </div>

            <div className="glass-panel p-5 rounded-2xl border border-white/10">
              <span className="text-xs text-gray-400 font-semibold uppercase">Unraid OS Status</span>
              <div className="text-3xl font-black text-white mt-2">{stats?.unraidVersion || '7.3.2'}</div>
              <p className="text-xs text-emerald-400 mt-1 font-mono">Uptime: {stats?.uptimeFormatted || '12d 4h'}</p>
              <div className="mt-4 pt-3 border-t border-white/5 text-xs text-gray-400 flex justify-between">
                <span>CPU Temp: 32°C</span>
                <span>Array: Geschützt</span>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
