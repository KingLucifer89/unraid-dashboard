'use client';

import React, { useState } from 'react';
import { Sidebar } from '@/components/navigation/Sidebar';
import { Header } from '@/components/navigation/Header';
import { HardDrive, Disc, CheckCircle, Database } from 'lucide-react';

export default function SpeicherPage() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const disks = [
    { name: 'Parity 1', size: '14 TB', temp: '31°C', status: 'Gültig', fs: 'Parity' },
    { name: 'Disk 1', size: '14 TB', temp: '32°C', status: 'OK', fs: 'XFS', free: '3.4 TB' },
    { name: 'Disk 2', size: '12 TB', temp: '33°C', status: 'OK', fs: 'XFS', free: '4.8 TB' },
    { name: 'Disk 3', size: '12 TB', temp: '30°C', status: 'OK', fs: 'XFS', free: '2.1 TB' },
    { name: 'Cache SSD 1', size: '2 TB NVMe', temp: '38°C', status: 'OK', fs: 'BTRFS (Pool)', free: '1.2 TB' },
    { name: 'Cache SSD 2', size: '2 TB NVMe', temp: '39°C', status: 'OK', fs: 'BTRFS (Pool)', free: '1.2 TB' },
  ];

  return (
    <div className="min-h-screen flex bg-[#060608]">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${collapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <Header editMode={false} setEditMode={() => {}} onOpenAddWidget={() => {}} setMobileOpen={setMobileOpen} />

        <main className="flex-1 p-4 lg:p-6 space-y-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <HardDrive className="text-shadow-red" />
              Unraid Speicher & Array Übersicht
            </h2>
            <p className="text-xs text-gray-400">
              Array-Status, Paritätslaufwerke, Festplattentemperaturen und NVMe Cache-Pools
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {disks.map((d, i) => (
              <div key={i} className="glass-panel p-4 rounded-2xl border border-white/10 hover:border-red-500/30 transition-all">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Disc className="text-red-400" size={18} />
                    <h4 className="text-xs font-bold text-white">{d.name}</h4>
                  </div>
                  <span className="text-[10px] text-emerald-400 bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-500/20">
                    {d.status}
                  </span>
                </div>
                <div className="text-xs text-gray-300 font-mono space-y-1">
                  <div>Kapazität: <span className="text-white font-semibold">{d.size}</span></div>
                  <div>Temperatur: <span className="text-emerald-400 font-semibold">{d.temp}</span></div>
                  <div>Dateisystem: <span className="text-gray-400">{d.fs}</span></div>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
