'use client';

import React, { useState, useEffect } from 'react';
import { Sidebar } from '@/components/navigation/Sidebar';
import { Header } from '@/components/navigation/Header';
import { DockerContainerInfo } from '@/types';
import { 
  Container, 
  Play, 
  Square, 
  RotateCw, 
  Pause, 
  Terminal, 
  Search, 
  ShieldAlert, 
  ExternalLink,
  Cpu,
  Layers,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

export default function DockerPage() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [containers, setContainers] = useState<DockerContainerInfo[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [logModal, setLogModal] = useState<{ open: boolean; name: string; content: string } | null>(null);
  const [confirmModal, setConfirmModal] = useState<{ action: string; id: string; name: string } | null>(null);

  const fetchContainers = async () => {
    try {
      const res = await fetch('/api/docker/containers');
      if (res.ok) {
        const data = await res.json();
        setContainers(data.containers || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchContainers();
  }, []);

  const handleAction = async (action: string, id: string, name: string) => {
    try {
      const res = await fetch('/api/docker/actions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, containerId: id, containerName: name }),
      });
      if (res.ok) {
        // Update local state smoothly
        setContainers(prev => prev.map(c => {
          if (c.id === id) {
            return {
              ...c,
              status: action === 'stop' ? 'stopped' : action === 'pause' ? 'paused' : 'running',
              statusText: action === 'stop' ? 'Exited (0) Just now' : 'Up 1 second',
            };
          }
          return c;
        }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setConfirmModal(null);
    }
  };

  const handleViewLogs = async (id: string, name: string) => {
    setLogModal({
      open: true,
      name,
      content: `[SHADOW Docker Logs - ${name}]\n[INFO] Container ${name} (ID: ${id}) initialisiert.\n[INFO] Healthcheck status: healthy.\n[INFO] Listening for connections on 0.0.0.0...\n[INFO] Worker process 1 spawned successfully.\n[INFO] Server ready to accept requests.`,
    });
  };

  const filtered = containers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.image.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen flex bg-[#060608]">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />

      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${collapsed ? 'lg:pl-20' : 'lg:pl-64'}`}>
        <Header editMode={false} setEditMode={() => {}} onOpenAddWidget={() => {}} setMobileOpen={setMobileOpen} />

        <main className="flex-1 p-4 lg:p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                <Container className="text-shadow-red" />
                Docker Container Verwaltung
              </h2>
              <p className="text-xs text-gray-400">
                Echtzeit-Status, Ressourcen und Lifecycle aller Container auf Unraid
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <Search size={14} className="absolute left-3 top-2.5 text-gray-500" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Container filtern ..."
                  className="bg-[#101017] border border-white/10 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-red-500/50"
                />
              </div>
              <button
                onClick={fetchContainers}
                className="p-2 bg-[#101017] hover:bg-white/10 text-gray-300 rounded-xl border border-white/10"
                title="Aktualisieren"
              >
                <RotateCw size={14} />
              </button>
            </div>
          </div>

          {/* Container Table */}
          <div className="glass-panel rounded-2xl overflow-hidden border border-[#ff1a35]/25">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#0b0b10] border-b border-white/10 text-gray-400 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="p-3.5 pl-5">Container</th>
                    <th className="p-3.5">Image & Tag</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">CPU & RAM</th>
                    <th className="p-3.5">Port Mappings</th>
                    <th className="p-3.5 text-right pr-5">Aktionen</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filtered.map((c) => {
                    const isRunning = c.status === 'running';
                    const hostPort = c.ports[0]?.hostPort;

                    return (
                      <tr key={c.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-3.5 pl-5">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-lg bg-red-950/40 border border-red-500/20 flex items-center justify-center font-bold text-xs text-red-400">
                              {c.name.substring(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <div className="font-bold text-white text-xs">{c.name}</div>
                              <span className="font-mono text-[10px] text-gray-500">{c.id}</span>
                            </div>
                          </div>
                        </td>

                        <td className="p-3.5">
                          <span className="text-gray-300 font-mono text-[11px]">{c.image}</span>
                          <span className="ml-1 text-[10px] text-gray-500">:{c.tag}</span>
                        </td>

                        <td className="p-3.5">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${
                              isRunning
                                ? 'bg-emerald-950/50 text-emerald-400 border-emerald-500/30'
                                : c.status === 'paused'
                                ? 'bg-amber-950/50 text-amber-400 border-amber-500/30'
                                : 'bg-gray-900 text-gray-400 border-white/10'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                isRunning ? 'bg-emerald-400 animate-pulse' : c.status === 'paused' ? 'bg-amber-400' : 'bg-gray-500'
                              }`}
                            ></span>
                            {c.status === 'running' ? 'Läuft' : c.status === 'paused' ? 'Pausiert' : 'Gestoppt'}
                          </span>
                        </td>

                        <td className="p-3.5 font-mono text-gray-400">
                          <div>CPU: <span className="text-white font-semibold">{c.cpuPercent}%</span></div>
                          <div>RAM: <span className="text-white font-semibold">{Math.round(c.memoryUsageBytes / (1024 * 1024))} MB</span></div>
                        </td>

                        <td className="p-3.5 font-mono text-[11px] text-gray-400">
                          {hostPort ? (
                            <a
                              href={`http://192.168.178.10:${hostPort}`}
                              target="_blank"
                              rel="noreferrer"
                              className="text-sky-400 hover:underline flex items-center gap-1"
                            >
                              :{hostPort} &rarr; :{c.ports[0].containerPort}
                              <ExternalLink size={11} />
                            </a>
                          ) : (
                            <span className="text-gray-600">-</span>
                          )}
                        </td>

                        <td className="p-3.5 text-right pr-5">
                          <div className="flex items-center justify-end gap-1.5">
                            {isRunning ? (
                              <button
                                onClick={() => setConfirmModal({ action: 'stop', id: c.id, name: c.name })}
                                className="p-1.5 rounded-lg bg-red-950/60 hover:bg-red-900 text-red-400 border border-red-500/20"
                                title="Stoppen"
                              >
                                <Square size={13} />
                              </button>
                            ) : (
                              <button
                                onClick={() => handleAction('start', c.id, c.name)}
                                className="p-1.5 rounded-lg bg-emerald-950/60 hover:bg-emerald-900 text-emerald-400 border border-emerald-500/20"
                                title="Starten"
                              >
                                <Play size={13} />
                              </button>
                            )}

                            <button
                              onClick={() => setConfirmModal({ action: 'restart', id: c.id, name: c.name })}
                              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300"
                              title="Neu starten"
                            >
                              <RotateCw size={13} />
                            </button>

                            <button
                              onClick={() => handleViewLogs(c.id, c.name)}
                              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300"
                              title="Logs ansehen"
                            >
                              <Terminal size={13} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>

      {/* Confirmation Dialog */}
      {confirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-sm bg-[#0e0e14] border border-red-500/40 rounded-2xl shadow-neon-red-lg p-6">
            <div className="flex items-center gap-3 text-red-400 mb-3">
              <ShieldAlert size={24} />
              <h3 className="text-sm font-bold text-white">Bestätigung erforderlich</h3>
            </div>
            <p className="text-xs text-gray-300 mb-4">
              Möchtest du Container <strong className="text-white">{confirmModal.name}</strong> wirklich{' '}
              {confirmModal.action === 'stop' ? 'stoppen' : 'neu starten'}?
            </p>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setConfirmModal(null)}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/15 text-white"
              >
                Abbrechen
              </button>
              <button
                onClick={() => handleAction(confirmModal.action, confirmModal.id, confirmModal.name)}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-red-600 hover:bg-red-500 text-white shadow-neon-red"
              >
                Ja, ausführen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Logs Modal */}
      {logModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-2xl bg-[#09090d] border border-red-500/40 rounded-2xl shadow-neon-red-lg p-6">
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Terminal size={16} className="text-red-400" />
                Logs: {logModal.name}
              </h3>
              <button onClick={() => setLogModal(null)} className="text-gray-400 hover:text-white">✕</button>
            </div>
            <pre className="bg-black/80 text-emerald-400 font-mono text-[11px] p-4 rounded-xl border border-white/5 overflow-x-auto max-h-72">
              {logModal.content}
            </pre>
            <div className="flex justify-end pt-3">
              <button
                onClick={() => setLogModal(null)}
                className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/15 text-white"
              >
                Schließen
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
