# SHADOW · UNRAID DASHBOARD

> *"Your Services. Your Server. Your Control."*

SHADOW ist ein eigenständiges, cyberpunk-inspiriertes SaaS-artiges Server-Dashboard & Kontrollzentrum für Unraid- und Home-Server, entwickelt mit Next.js 14 (App Router), React 18, TypeScript, Tailwind CSS, Prisma und SQLite.

![SHADOW Dashboard UI](public/icon.png)

## Highlights

- 🔴 **Cyberpunk Neon-Red Glassmorphism**: Hochwertiges, technisches Design mit dezentem Leuchten, transparenten Panels und responsiver Typografie.
- 🐳 **Native Docker-Erkennung & Steuerung**: Automatische Erkennung aller Container auf dem Unraid-Host via `/var/run/docker.sock` inklusive Start/Stop/Restart, Logs und Ressourcenüberwachung.
- 🎛️ **Echtes Edit-Mode Drag & Drop Grid**: Frei anordnungs- und skalierbare Widgets mit persistenter Speicherung in SQLite.
- 🎬 **Multi-Media Provider Architektur**: Vollwertige API-Adapter für Jellyfin, Emby und Plex mit Echtzeit-Streams (Bitrate, Direct Play / Transcode, Poster).
- 📡 **ARR & Downloader Integrationen**: Schnittstellen für Sonarr, Radarr, Lidarr, Prowlarr und qBittorrent.
- 🏠 **Smart Home & Monitoring**: Anbindung für Home Assistant (Entities), Immich (Foto-Server) und Grafana.
- 🏪 **Marktplatz & Plugin-System**: Durchsuchen von Docker Hub (Docker.io) und Community-Containern mit 1-Klick Installation.
- 🇩🇪 **Standardmäßig Deutsch**: Vollständig lokalisierte Benutzeroberfläche und Dokumentation.
- 📦 **Unraid-Kompatibel**: Fertiges XML-Template für Docker-Applikationen, standardmäßig auf **Port 8086**.

---

## Schnellstart

### 1. Manuelle Ausführung mit Node.js

```bash
git clone https://github.com/shadow/unraid-dashboard.git
cd unraid-dashboard

# Abhängigkeiten installieren
npm install

# SQLite Datenbank initialisieren
npx prisma db push

# Produktions-Build erstellen
npm run build

# Starten auf Port 8086
npm run start
```

Das Dashboard ist nun unter `http://localhost:8086` erreichbar.

---

### 2. Docker Run

```bash
docker run -d \
  --name shadow \
  -p 8086:8086 \
  -v /mnt/user/appdata/shadow:/data \
  -v /var/run/docker.sock:/var/run/docker.sock:ro \
  ghcr.io/shadow/unraid-dashboard:latest
```

---

### 3. Docker Compose

```yaml
version: '3.8'

services:
  shadow:
    image: ghcr.io/shadow/unraid-dashboard:latest
    container_name: shadow
    ports:
      - "8086:8086"
    volumes:
      - /mnt/user/appdata/shadow:/data
      - /var/run/docker.sock:/var/run/docker.sock:ro
    environment:
      - NODE_ENV=production
      - PORT=8086
      - DATABASE_URL=file:/data/shadow.db
      - DOCKER_SOCKET=/var/run/docker.sock
    restart: unless-stopped
```

---

## Unraid Installation

1. Kopiere die Datei `my-shadow-dashboard.xml` auf dein Unraid-Flash-Laufwerk unter:  
   `/boot/config/plugins/dockerMan/templates-user/`
2. Öffne das Unraid WebGUI und navigiere zu **Docker** &rarr; **Add Container**.
3. Wähle im Template-Auswahlfeld **shadow** aus.
4. Überprüfe den Port `8086` und den persistenten Pfad `/mnt/user/appdata/shadow`.
5. Klicke auf **Apply**.

---

## Projektstruktur

```
shadow/
├── app/                           # Next.js App Router
│   ├── api/                       # REST APIs (Docker, System, Apps, Media, Health)
│   ├── docker/                    # Docker Management Page
│   ├── apps/                      # Apps Verzeichnis Page
│   ├── system/                    # Host Metriken Page
│   ├── netzwerk/                  # Netzwerk & Bandbreite
│   ├── speicher/                  # Unraid Array Disks Page
│   ├── plugins/                   # Plugin Verwaltung
│   ├── marktplatz/                # Container Marktplatz
│   ├── logs/                      # Audit Log Viewer
│   ├── backup/                    # Snapshot Backup/Export
│   ├── benachrichtigungen/        # Notifikationszentrale
│   └── einstellungen/             # Systemeinstellungen
├── components/                    # UI & Dashboard Widgets
│   ├── dashboard/                 # Drag & Drop Grid & Layout
│   ├── widgets/                   # Modular Widget Implementations
│   ├── navigation/                # Sidebar, Header, Omnisearch
│   └── marketplace/               # Marketplace Panel
├── integrations/                  # Provider/Adapter Layer (Jellyfin, Emby, Plex, ARR)
├── server/                        # Docker Client & System Stats Reader
├── prisma/                        # SQLite Datenbankschema
├── docs/                          # Deutsches Offline-HTML Handbuch (docs/index.html)
├── Dockerfile                     # Multi-Stage Produktions-Dockerfile
├── docker-compose.yml             # Compose Datei
└── my-shadow-dashboard.xml        # Unraid Docker Template
```

---

## Lizenz

Entwickelt für die Unraid- und Self-Hosting-Community.
