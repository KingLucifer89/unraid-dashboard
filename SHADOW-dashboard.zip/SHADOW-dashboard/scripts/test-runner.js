const { execSync } = require('child_process');
const http = require('http');

console.log('--- [SHADOW Dashboard Architecture Test Runner] ---');

// 1. Check TypeScript files
console.log('✓ Validating core directories and files...');
const fs = require('fs');
const files = [
  'Dockerfile',
  'docker-compose.yml',
  'my-shadow-dashboard.xml',
  'docs/index.html',
  'README.md',
  'prisma/schema.prisma',
  'lib/prisma.ts',
  'server/docker/docker-client.ts',
  'server/system/system-stats.ts',
  'integrations/media/jellyfin.ts',
  'integrations/media/emby.ts',
  'integrations/media/plex.ts',
  'integrations/arr/arr-client.ts',
  'components/dashboard/DashboardGrid.tsx',
];

for (const f of files) {
  if (!fs.existsSync(f)) {
    console.error(`✗ Missing required file: ${f}`);
    process.exit(1);
  }
}
console.log('✓ All critical files present.');

console.log('--- [All Sanity Tests Passed] ---');
