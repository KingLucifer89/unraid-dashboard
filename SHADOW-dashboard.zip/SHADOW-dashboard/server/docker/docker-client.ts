import fs from 'fs';
import http from 'http';
import { DockerContainerInfo } from '@/types';

export interface DockerContainerRaw {
  Id: string;
  Names: string[];
  Image: string;
  ImageID: string;
  Command: string;
  Created: number;
  State: string;
  Status: string;
  Ports: Array<{
    IP?: string;
    PrivatePort: number;
    PublicPort?: number;
    Type: string;
  }>;
  Labels: Record<string, string>;
  Mounts: Array<{
    Type: string;
    Source: string;
    Destination: string;
    Mode: string;
  }>;
}

export class DockerClient {
  private socketPath: string;

  constructor(socketPath?: string) {
    this.socketPath = socketPath || process.env.DOCKER_SOCKET || '/var/run/docker.sock';
  }

  public isAvailable(): boolean {
    try {
      return fs.existsSync(this.socketPath);
    } catch {
      return false;
    }
  }

  private request<T>(path: string, method: string = 'GET', postData?: unknown): Promise<T> {
    return new Promise((resolve, reject) => {
      if (!this.isAvailable()) {
        return reject(new Error('Docker Socket nicht verfügbar (/var/run/docker.sock)'));
      }

      const options: http.RequestOptions = {
        socketPath: this.socketPath,
        path,
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        timeout: 5000,
      };

      const req = http.request(options, (res) => {
        let body = '';
        res.setEncoding('utf8');
        res.on('data', (chunk) => {
          body += chunk;
        });
        res.on('end', () => {
          if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
            try {
              if (body) {
                resolve(JSON.parse(body) as T);
              } else {
                resolve({} as T);
              }
            } catch (err) {
              resolve(body as unknown as T);
            }
          } else {
            reject(new Error(`Docker API Fehler ${res.statusCode}: ${body || res.statusMessage}`));
          }
        });
      });

      req.on('error', (err) => {
        reject(err);
      });

      req.on('timeout', () => {
        req.destroy();
        reject(new Error('Docker Socket Timeout'));
      });

      if (postData) {
        req.write(JSON.stringify(postData));
      }
      req.end();
    });
  }

  public async getContainers(all: boolean = true): Promise<DockerContainerInfo[]> {
    if (!this.isAvailable()) {
      return [];
    }

    try {
      const rawContainers = await this.request<DockerContainerRaw[]>(`/containers/json?all=${all ? '1' : '0'}`);
      
      return rawContainers.map((c) => {
        const name = (c.Names && c.Names[0]) ? c.Names[0].replace(/^\//, '') : c.Id.substring(0, 12);
        let status: 'running' | 'stopped' | 'paused' | 'restarting' | 'error' = 'stopped';
        const rawState = (c.State || '').toLowerCase();
        
        if (rawState === 'running') status = 'running';
        else if (rawState === 'paused') status = 'paused';
        else if (rawState === 'restarting') status = 'restarting';
        else if (rawState === 'dead' || rawState === 'exited') status = 'stopped';

        const ports = (c.Ports || []).map(p => ({
          hostPort: p.PublicPort,
          containerPort: p.PrivatePort,
          protocol: p.Type,
        }));

        const mounts = (c.Mounts || []).map(m => ({
          source: m.Source,
          destination: m.Destination,
          mode: m.Mode,
        }));

        const imageParts = (c.Image || '').split(':');
        const image = imageParts[0];
        const tag = imageParts[1] || 'latest';

        return {
          id: c.Id.substring(0, 12),
          name,
          image,
          tag,
          status,
          statusText: c.Status || c.State,
          uptime: c.Status,
          created: c.Created,
          cpuPercent: 0,
          memoryUsageBytes: 0,
          memoryLimitBytes: 0,
          memoryUsagePercent: 0,
          networkRxBytes: 0,
          networkTxBytes: 0,
          ports,
          mounts,
          command: c.Command || '',
        };
      });
    } catch (err) {
      console.error('Docker getContainers error:', err);
      return [];
    }
  }

  public async startContainer(id: string): Promise<boolean> {
    await this.request(`/containers/${id}/start`, 'POST');
    return true;
  }

  public async stopContainer(id: string): Promise<boolean> {
    await this.request(`/containers/${id}/stop`, 'POST');
    return true;
  }

  public async restartContainer(id: string): Promise<boolean> {
    await this.request(`/containers/${id}/restart`, 'POST');
    return true;
  }

  public async pauseContainer(id: string): Promise<boolean> {
    await this.request(`/containers/${id}/pause`, 'POST');
    return true;
  }

  public async unpauseContainer(id: string): Promise<boolean> {
    await this.request(`/containers/${id}/unpause`, 'POST');
    return true;
  }

  public async getLogs(id: string, tail: number = 100): Promise<string> {
    if (!this.isAvailable()) return 'Docker Socket nicht verfügbar.';
    try {
      const logs = await this.request<string>(`/containers/${id}/logs?stdout=1&stderr=1&tail=${tail}`);
      return typeof logs === 'string' ? logs : JSON.stringify(logs);
    } catch (err: unknown) {
      return `Fehler beim Abrufen der Logs: ${err instanceof Error ? err.message : String(err)}`;
    }
  }
}

export const dockerClient = new DockerClient();
