export interface DockerContainerInfo {
  id: string;
  name: string;
  image: string;
  tag: string;
  status: 'running' | 'stopped' | 'paused' | 'restarting' | 'error';
  statusText: string;
  uptime: string;
  created: number;
  cpuPercent: number;
  memoryUsageBytes: number;
  memoryLimitBytes: number;
  memoryUsagePercent: number;
  networkRxBytes: number;
  networkTxBytes: number;
  ports: Array<{ hostPort?: number; containerPort: number; protocol: string }>;
  mounts: Array<{ source: string; destination: string; mode: string }>;
  command: string;
}

export interface SystemStats {
  hostname: string;
  unraidVersion: string;
  uptimeSeconds: number;
  uptimeFormatted: string;
  cpu: {
    usagePercent: number;
    cores: number;
    model: string;
    loadAverage: [number, number, number];
    temperatureC?: number;
  };
  ram: {
    usedBytes: number;
    totalBytes: number;
    freeBytes: number;
    usagePercent: number;
  };
  storage: {
    usedBytes: number;
    totalBytes: number;
    freeBytes: number;
    usagePercent: number;
    disksCount: { used: number; total: number };
  };
  network: {
    downloadSpeedBps: number;
    uploadSpeedBps: number;
    totalRxBytes: number;
    totalTxBytes: number;
    linkSpeed: string;
    history: Array<{ time: string; rx: number; tx: number }>;
  };
}

export interface MediaSession {
  id: string;
  provider?: 'jellyfin' | 'emby' | 'plex';
  service: string;
  user: string;
  title: string;
  seriesName?: string;
  seasonEpisode?: string;
  mediaType?: 'Episode' | 'Movie' | 'Audio' | 'LiveTv';
  playbackPositionSeconds?: number;
  durationSeconds?: number;
  percentage?: number;
  isPaused?: boolean;
  playbackMode: 'Direct Play' | 'Transcoding' | 'DirectStream' | string;
  quality: string;
  bitrateMbps: number;
  client?: string;
  device?: string;
  posterUrl?: string;
}

export interface AppItemDto {
  id: string;
  name: string;
  url: string;
  icon?: string | null;
  category: string;
  description?: string | null;
  color?: string | null;
  openNewTab: boolean;
  containerId?: string | null;
  healthUrl?: string | null;
  status: string;
  order: number;
}

export interface IntegrationStatusDto {
  id: string;
  name: string;
  type: string;
  url?: string;
  enabled: boolean;
  status: 'connected' | 'error' | 'not_configured';
  lastChecked?: string;
  version?: string;
}

export interface MarketplacePlugin {
  id: string;
  name: string;
  version: string;
  category: 'Media' | 'Tools' | 'System' | 'Netzwerk' | 'Monitoring' | 'Downloads' | 'Smart Home' | 'Productivity';
  author: string;
  description: string;
  source: 'docker.io' | 'custom' | 'community';
  icon?: string;
  rating?: number;
  stars?: number;
  installed: boolean;
  dockerImage?: string;
  defaultPort?: number;
  defaultVolume?: string;
}

export interface WidgetLayoutItem {
  id: string;
  type: 'system-overview' | 'docker-containers' | 'media-server' | 'apps' | 'docker-overview' | 'server-info' | 'api-integrations' | 'quick-actions' | 'custom-widget';
  title: string;
  x: number;
  y: number;
  w: number;
  h: number;
  visible: boolean;
  config?: Record<string, unknown>;
}
