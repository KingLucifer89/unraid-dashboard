/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        shadow: {
          950: '#030305',
          900: '#07070a',
          850: '#0c0c10',
          800: '#121217',
          700: '#1a1a24',
          600: '#262633',
          red: {
            DEFAULT: '#ff1a35',
            glow: '#ff2a4b',
            deep: '#8f0015',
            dark: '#40000a',
          }
        }
      },
      boxShadow: {
        'neon-red': '0 0 15px rgba(255, 26, 53, 0.35)',
        'neon-red-lg': '0 0 25px rgba(255, 26, 53, 0.55), 0 0 50px rgba(255, 26, 53, 0.2)',
        'neon-border': 'inset 0 0 12px rgba(255, 26, 53, 0.25)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow-pulse': 'glow 2.5s ease-in-out infinite alternate',
      },
      keyframes: {
        glow: {
          '0%': { boxShadow: '0 0 8px rgba(255, 26, 53, 0.3)' },
          '100%': { boxShadow: '0 0 20px rgba(255, 26, 53, 0.7)' },
        }
      }
    },
  },
  plugins: [],
}
