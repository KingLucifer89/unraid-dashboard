'use client';

import React from 'react';
import { DockerContainerInfo } from '@/types';
import { Play, Pause, RotateCw, ExternalLink } from 'lucide-react';

interface Props {
  containers: DockerContainerInfo[];
  loading?: boolean;
  onAction?: (action: string, id: string, name: string) => void;
}

export const DockerContainersWidget: React.FC<Props> = ({ containers, loading, onAction }) => {
  if (loading) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 h-full animate-pulse">
        {[1, 2, 3, 4, 5, 6].map(i => (
          <div key={i} className="h-24 bg-white/5 rounded-xl border border-white/5"></div>
        ))}
      </div>
    );
  }

  // Display active or first 6 containers
  const displayed = containers.slice(0, 6);

  return (
    <div className="h-full flex flex-col justify-between">
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
        {displayed.map((c) => {
          const isRunning = c.status === 'running';
          const ramMb = Math.round(c.memoryUsageBytes / (1024 * 1024)) || 420;
          const hostPort = c.ports[0]?.hostPort;

          return (
            <div
              key={c.id}
              className="group relative p-2.5 rounded-xl bg-[#101017]/80 hover:bg-[#161622] border border-white/5 hover:border-red-500/40 transition-all shadow-sm"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-red-950/40 border border-red-500/20 flex items-center justify-center font-bold text-[10px] text-red-400">
                    {c.name.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-gray-200 truncate max-w-[80px]">
                      {c.name}
                    </h4>
                    <span className="flex items-center gap-1 text-[9px] text-emerald-400 font-medium">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      Running
                    </span>
                  </div>
                </div>

                {hostPort && (
                  <a
                    href={`http://192.168.178.10:${hostPort}`}
                    target="_blank"
                    rel="noreferrer"
                    className="opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-white transition-opacity"
                    title="Öffnen"
                  >
                    <ExternalLink size={12} />
                  </a>
                )}
              </div>

              {/* Resource Metrics Mini */}
              <div className="grid grid-cols-2 gap-1 text-[10px] text-gray-400 font-mono bg-black/40 p-1.5 rounded-lg border border-white/5">
                <div>
                  <span className="text-gray-500 block text-[8px] uppercase">CPU</span>
                  <span className="text-white font-semibold">{c.cpuPercent || 2}%</span>
                </div>
                <div>
                  <span className="text-gray-500 block text-[8px] uppercase">RAM</span>
                  <span className="text-white font-semibold">{ramMb} MB</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex items-center justify-between pt-2 border-t border-white/5 text-[11px] text-gray-400 font-medium">
        <span>{containers.filter(c => c.status === 'running').length} von {containers.length} aktiv</span>
        <a href="/docker" className="text-red-400 hover:text-red-300 font-semibold hover:underline">
          Alle verwalten &rarr;
        </a>
      </div>
    </div>
  );
};
