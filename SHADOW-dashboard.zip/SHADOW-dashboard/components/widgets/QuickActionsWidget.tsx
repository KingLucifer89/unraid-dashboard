'use client';

import React, { useState } from 'react';
import { Play, ShieldCheck, RefreshCw, FileText } from 'lucide-react';

export const QuickActionsWidget: React.FC = () => {
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const handleAction = (label: string) => {
    setStatusMsg(`Aktion ausgeführt: "${label}"`);
    setTimeout(() => setStatusMsg(null), 3000);
  };

  const actions = [
    { label: 'Neuen Container starten', icon: Play, link: '/marktplatz' },
    { label: 'Backup erstellen', icon: ShieldCheck, link: '/backup' },
    { label: 'Systemupdate prüfen', icon: RefreshCw, action: () => handleAction('Systemupdate geprüft - Alles aktuell') },
    { label: 'Logs anzeigen', icon: FileText, link: '/logs' },
  ];

  return (
    <div className="flex flex-col justify-between h-full">
      <div className="grid grid-cols-2 gap-2">
        {actions.map((act, idx) => {
          const Icon = act.icon;
          return act.link ? (
            <a
              key={idx}
              href={act.link}
              className="flex items-center gap-2 p-2.5 rounded-xl bg-black/40 hover:bg-red-950/30 border border-white/5 hover:border-red-500/30 text-xs font-semibold text-gray-200 hover:text-white transition-all group"
            >
              <div className="p-1 rounded-md bg-red-600/20 text-red-400 group-hover:scale-105 transition-transform">
                <Icon size={14} />
              </div>
              <span className="truncate">{act.label}</span>
            </a>
          ) : (
            <button
              key={idx}
              onClick={act.action}
              className="flex items-center gap-2 p-2.5 rounded-xl bg-black/40 hover:bg-red-950/30 border border-white/5 hover:border-red-500/30 text-xs font-semibold text-gray-200 hover:text-white transition-all group text-left"
            >
              <div className="p-1 rounded-md bg-red-600/20 text-red-400 group-hover:scale-105 transition-transform">
                <Icon size={14} />
              </div>
              <span className="truncate">{act.label}</span>
            </button>
          );
        })}
      </div>

      {statusMsg && (
        <div className="mt-2 p-1.5 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-[10px] text-emerald-300 text-center animate-in fade-in">
          {statusMsg}
        </div>
      )}
    </div>
  );
};
