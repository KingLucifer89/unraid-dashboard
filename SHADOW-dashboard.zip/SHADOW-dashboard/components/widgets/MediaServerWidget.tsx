'use client';

import React from 'react';
import { MediaSession } from '@/types';
import { Play, Tv, Film, Disc } from 'lucide-react';

interface Props {
  sessions: MediaSession[];
  loading?: boolean;
}

export const MediaServerWidget: React.FC<Props> = ({ sessions, loading }) => {
  if (loading) {
    return (
      <div className="space-y-3 h-full animate-pulse p-2">
        <div className="h-16 bg-white/5 rounded-xl"></div>
        <div className="h-16 bg-white/5 rounded-xl"></div>
        <div className="h-16 bg-white/5 rounded-xl"></div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col justify-between">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-semibold text-gray-300">
          Aktive Streams ({sessions.length})
        </span>
        <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/20">
          Direct / Transcode
        </span>
      </div>

      <div className="space-y-2.5 flex-1 overflow-y-auto max-h-[220px]">
        {sessions.map((stream) => (
          <div
            key={stream.id}
            className="p-2.5 rounded-xl bg-[#101017]/90 border border-white/5 hover:border-red-500/30 transition-all flex items-center gap-3 group"
          >
            {/* Poster Thumbnail Placeholder */}
            <div className="w-10 h-14 rounded-lg bg-gradient-to-t from-red-950 to-black/80 border border-red-500/20 flex items-center justify-center text-red-400 flex-shrink-0 relative overflow-hidden">
              <Film size={18} className="text-red-500/70" />
              <div className="absolute inset-0 bg-red-600/10 group-hover:bg-transparent transition-colors"></div>
            </div>

            {/* Stream Metadata & Progress */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <h4 className="text-xs font-bold text-white truncate group-hover:text-red-400 transition-colors">
                  {stream.title}
                </h4>
                <span className="text-[10px] font-mono font-semibold text-gray-300 flex-shrink-0">
                  {stream.bitrateMbps} Mbps
                </span>
              </div>

              <div className="flex items-center gap-2 text-[10px] text-gray-400 mt-0.5">
                <span className="font-medium text-gray-300">{stream.service}</span>
                <span>•</span>
                <span>{stream.quality}</span>
                <span>•</span>
                <span className={stream.playbackMode === 'Direct Play' ? 'text-sky-400' : 'text-amber-400'}>
                  {stream.playbackMode}
                </span>
              </div>

              {/* Progress bar */}
              <div className="mt-2 flex items-center gap-2">
                <div className="flex-1 h-1 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-red-600 shadow-neon-red"
                    style={{ width: `${stream.percentage}%` }}
                  ></div>
                </div>
                <span className="text-[9px] font-mono text-gray-400">
                  {stream.percentage}%
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
