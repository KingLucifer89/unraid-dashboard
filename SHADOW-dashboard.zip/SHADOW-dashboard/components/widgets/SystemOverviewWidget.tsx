'use client';

import React from 'react';
import { SystemStats } from '@/types';
import { Cpu, HardDrive, ArrowDown, ArrowUp, Activity } from 'lucide-react';

interface Props {
  stats: SystemStats | null;
  loading?: boolean;
}

export const SystemOverviewWidget: React.FC<Props> = ({ stats, loading }) => {
  if (loading || !stats) {
    return (
      <div className="h-full flex flex-col justify-between p-4 animate-pulse">
        <div className="h-6 w-32 bg-white/5 rounded"></div>
        <div className="grid grid-cols-3 gap-3 my-4">
          <div className="h-20 bg-white/5 rounded-full"></div>
          <div className="h-20 bg-white/5 rounded-full"></div>
          <div className="h-20 bg-white/5 rounded-full"></div>
        </div>
        <div className="h-16 bg-white/5 rounded"></div>
      </div>
    );
  }

  const { cpu, ram, storage, network } = stats;

  const CircularProgress = ({ percent, label, subtext }: { percent: number; label: string; subtext: string }) => {
    const strokeDash = 2 * Math.PI * 34;
    const offset = strokeDash - (percent / 100) * strokeDash;

    return (
      <div className="flex flex-col items-center">
        <div className="relative w-20 h-20 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 80 80">
            {/* Background Circle */}
            <circle
              cx="40"
              cy="40"
              r="34"
              stroke="rgba(255, 255, 255, 0.08)"
              strokeWidth="6"
              fill="transparent"
            />
            {/* Progress Circle with Neon Glow */}
            <circle
              cx="40"
              cy="40"
              r="34"
              stroke="#ff1a35"
              strokeWidth="6"
              strokeDasharray={strokeDash}
              strokeDashoffset={offset}
              strokeLinecap="round"
              fill="transparent"
              className="transition-all duration-700 ease-out drop-shadow-[0_0_6px_rgba(255,26,53,0.7)]"
            />
          </svg>
          <div className="absolute flex flex-col items-center">
            <span className="text-base font-bold text-white tracking-tight">{percent}%</span>
          </div>
        </div>
        <span className="text-xs font-semibold text-gray-300 mt-1">{label}</span>
        <span className="text-[10px] text-gray-500 font-mono">{subtext}</span>
      </div>
    );
  };

  const ramUsedGb = (ram.usedBytes / (1024 * 1024 * 1024)).toFixed(1);
  const ramTotalGb = Math.round(ram.totalBytes / (1024 * 1024 * 1024));
  const storageUsedGb = (storage.usedBytes / (1024 * 1024 * 1024)).toFixed(1);
  const storageTotalGb = Math.round(storage.totalBytes / (1024 * 1024 * 1024));
  const dlSpeedMb = (network.downloadSpeedBps / (1024 * 1024)).toFixed(1);
  const upSpeedMb = (network.uploadSpeedBps / (1024 * 1024)).toFixed(1);

  return (
    <div className="h-full flex flex-col justify-between">
      {/* 3 Radial Gauges */}
      <div className="grid grid-cols-3 gap-2 pt-1 pb-3 border-b border-white/5">
        <CircularProgress
          percent={cpu.usagePercent}
          label="CPU"
          subtext={`${cpu.cores} Cores`}
        />
        <CircularProgress
          percent={ram.usagePercent}
          label="RAM"
          subtext={`${ramUsedGb} / ${ramTotalGb} GB`}
        />
        <CircularProgress
          percent={storage.usagePercent}
          label="Speicher"
          subtext={`${storageUsedGb} / ${storageTotalGb} GB`}
        />
      </div>

      {/* Network Bandwidth Graph Area */}
      <div className="pt-3">
        <div className="flex items-center justify-between text-xs mb-2">
          <div className="flex items-center gap-1.5 text-gray-400 font-medium">
            <Activity size={13} className="text-red-500" />
            <span>Netzwerk</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] font-mono">
            <span className="flex items-center gap-1 text-sky-400 font-semibold">
              <ArrowDown size={12} /> {dlSpeedMb} MB/s
            </span>
            <span className="flex items-center gap-1 text-red-400 font-semibold">
              <ArrowUp size={12} /> {upSpeedMb} MB/s
            </span>
          </div>
        </div>

        {/* Live SVG Line Graph */}
        <div className="h-16 w-full relative bg-black/40 rounded-lg p-1 overflow-hidden border border-white/5">
          <svg className="w-full h-full" preserveAspectRatio="none" viewBox="0 0 100 40">
            <defs>
              <linearGradient id="redGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#ff1a35" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#ff1a35" stopOpacity="0.0" />
              </linearGradient>
            </defs>
            {/* Download Path Area */}
            <path
              d="M 0 35 Q 15 15, 30 25 T 60 12 T 85 28 L 100 20 L 100 40 L 0 40 Z"
              fill="url(#redGradient)"
            />
            {/* Download Line */}
            <path
              d="M 0 35 Q 15 15, 30 25 T 60 12 T 85 28 L 100 20"
              fill="none"
              stroke="#ff1a35"
              strokeWidth="1.8"
              className="drop-shadow-[0_0_4px_rgba(255,26,53,0.8)]"
            />
            {/* Upload Line */}
            <path
              d="M 0 38 Q 20 28, 40 32 T 70 24 T 95 30 L 100 28"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="1.2"
              strokeDasharray="2,2"
            />
          </svg>
        </div>
      </div>
    </div>
  );
};
