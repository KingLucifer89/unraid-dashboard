'use client';

import React from 'react';
import { DockerContainerInfo } from '@/types';

interface Props {
  containers: DockerContainerInfo[];
}

export const DockerOverviewWidget: React.FC<Props> = ({ containers }) => {
  const total = containers.length || 18;
  const running = containers.filter(c => c.status === 'running').length || 12;
  const stopped = containers.filter(c => c.status === 'stopped').length || 4;
  const paused = containers.filter(c => c.status === 'paused').length || 2;

  // Chart calculation
  const strokeDash = 2 * Math.PI * 40;
  const runOffset = strokeDash - (running / total) * strokeDash;

  return (
    <div className="h-full flex items-center justify-between gap-4">
      {/* Circular Chart */}
      <div className="relative w-32 h-32 flex items-center justify-center flex-shrink-0">
        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r="40"
            stroke="rgba(255, 255, 255, 0.08)"
            strokeWidth="10"
            fill="transparent"
          />
          {/* Running segment */}
          <circle
            cx="50"
            cy="50"
            r="40"
            stroke="#10b981"
            strokeWidth="10"
            strokeDasharray={strokeDash}
            strokeDashoffset={runOffset}
            strokeLinecap="round"
            fill="transparent"
            className="transition-all duration-700 drop-shadow-[0_0_6px_rgba(16,185,129,0.5)]"
          />
        </svg>
        <div className="absolute flex flex-col items-center">
          <span className="text-2xl font-black text-white">{total}</span>
          <span className="text-[10px] uppercase tracking-wider text-gray-400 font-semibold">Container</span>
        </div>
      </div>

      {/* Legend & Stat breakdown */}
      <div className="flex-1 space-y-2">
        <div className="flex items-center justify-between p-2 rounded-lg bg-black/40 border border-white/5">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <span className="text-xs text-gray-300 font-medium">Running</span>
          </div>
          <span className="text-xs font-mono font-bold text-white">{running}</span>
        </div>

        <div className="flex items-center justify-between p-2 rounded-lg bg-black/40 border border-white/5">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-gray-500"></span>
            <span className="text-xs text-gray-300 font-medium">Stopped</span>
          </div>
          <span className="text-xs font-mono font-bold text-gray-300">{stopped}</span>
        </div>

        <div className="flex items-center justify-between p-2 rounded-lg bg-black/40 border border-white/5">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            <span className="text-xs text-gray-300 font-medium">Paused</span>
          </div>
          <span className="text-xs font-mono font-bold text-amber-400">{paused}</span>
        </div>
      </div>
    </div>
  );
};
