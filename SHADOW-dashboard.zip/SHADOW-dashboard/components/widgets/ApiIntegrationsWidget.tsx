'use client';

import React from 'react';
import { IntegrationStatusDto } from '@/types';
import { CheckCircle2, AlertCircle, Film, PlayCircle, Tv, Video } from 'lucide-react';

interface Props {
  integrations: IntegrationStatusDto[];
}

export const ApiIntegrationsWidget: React.FC<Props> = ({ integrations }) => {
  const defaultIntegrations = [
    { id: 'jellyfin', name: 'Jellyfin API', status: 'connected', version: 'v10.9.11', icon: Film },
    { id: 'emby', name: 'Emby API', status: 'connected', version: 'v4.8.10', icon: PlayCircle },
    { id: 'sonarr', name: 'Sonarr API', status: 'connected', version: 'v3.0.10', icon: Tv },
    { id: 'radarr', name: 'Radarr API', status: 'connected', version: 'v5.0.0', icon: Video },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 h-full items-center">
      {defaultIntegrations.map((item) => {
        const Icon = item.icon;
        return (
          <div
            key={item.id}
            className="p-3 rounded-xl bg-[#101017] border border-white/5 hover:border-red-500/40 transition-all flex flex-col items-center text-center relative group"
          >
            <div className="p-2 rounded-xl bg-red-950/40 text-red-400 border border-red-500/20 mb-1.5 group-hover:scale-105 transition-transform">
              <Icon size={18} />
            </div>

            <span className="text-xs font-bold text-white">{item.name}</span>
            <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-medium mt-0.5">
              <CheckCircle2 size={11} /> Verbunden
            </span>
            <span className="text-[9px] font-mono text-gray-500">{item.version}</span>
          </div>
        );
      })}
    </div>
  );
};
