'use client';

import React from 'react';
import { AppItemDto } from '@/types';
import { ExternalLink, Film, PlayCircle, Tv, Video, Download, Home, Image, Activity, Layers } from 'lucide-react';

interface Props {
  apps: AppItemDto[];
  loading?: boolean;
}

export const AppsWidget: React.FC<Props> = ({ apps, loading }) => {
  if (loading) {
    return (
      <div className="grid grid-cols-4 gap-2.5 h-full animate-pulse">
        {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
          <div key={i} className="h-20 bg-white/5 rounded-xl"></div>
        ))}
      </div>
    );
  }

  const getAppIcon = (name: string) => {
    const n = name.toLowerCase();
    if (n.includes('jellyfin')) return Film;
    if (n.includes('emby')) return PlayCircle;
    if (n.includes('sonarr')) return Tv;
    if (n.includes('radarr')) return Video;
    if (n.includes('qbittorrent')) return Download;
    if (n.includes('home') || n.includes('assistant')) return Home;
    if (n.includes('immich')) return Image;
    if (n.includes('grafana')) return Activity;
    return Layers;
  };

  return (
    <div className="h-full flex flex-col justify-between">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {apps.slice(0, 8).map((app) => {
          const Icon = getAppIcon(app.name);
          return (
            <a
              key={app.id}
              href={app.url}
              target={app.openNewTab ? '_blank' : '_self'}
              rel="noreferrer"
              className="group p-2.5 rounded-xl bg-[#101017]/80 hover:bg-[#181824] border border-white/5 hover:border-red-500/40 transition-all flex flex-col items-center text-center relative"
            >
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center mb-1.5 transition-transform group-hover:scale-110 shadow-md"
                style={{ backgroundColor: `${app.color || '#ff1a35'}20`, border: `1px solid ${app.color || '#ff1a35'}50` }}
              >
                <Icon size={20} style={{ color: app.color || '#ff1a35' }} />
              </div>

              <span className="text-xs font-bold text-gray-200 truncate w-full group-hover:text-white">
                {app.name}
              </span>
              <span className="text-[9px] text-gray-400 truncate w-full">
                {app.category}
              </span>

              <div className="flex items-center gap-1 mt-1 text-[9px] text-emerald-400 font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Online
              </div>

              <ExternalLink size={10} className="absolute top-2 right-2 text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity" />
            </a>
          );
        })}
      </div>
    </div>
  );
};
