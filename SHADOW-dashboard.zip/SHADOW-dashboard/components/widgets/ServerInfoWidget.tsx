'use client';

import React from 'react';
import { SystemStats } from '@/types';
import { Server, Clock, Thermometer, HardDrive, Disc, Wifi } from 'lucide-react';

interface Props {
  stats: SystemStats | null;
}

export const ServerInfoWidget: React.FC<Props> = ({ stats }) => {
  const infoItems = [
    { label: 'Unraid Version', value: stats?.unraidVersion || '7.3.2', icon: Server, color: 'text-red-400' },
    { label: 'Betriebszeit', value: stats?.uptimeFormatted || '12d 4h 32m', icon: Clock, color: 'text-amber-400' },
    { label: 'Temperatur', value: `${stats?.cpu.temperatureC || 32}°C`, icon: Thermometer, color: 'text-emerald-400' },
    { label: 'Freier Speicher', value: `${((stats?.storage.freeBytes || 52.3 * 1024 * 1024 * 1024) / (1024 * 1024 * 1024)).toFixed(1)} GB`, icon: HardDrive, color: 'text-sky-400' },
    { label: 'Festplatten', value: `${stats?.storage.disksCount.used || 4} / ${stats?.storage.disksCount.total || 6}`, icon: Disc, color: 'text-purple-400' },
    { label: 'Netzwerk', value: stats?.network.linkSpeed || '1 Gbps', icon: Wifi, color: 'text-emerald-400' },
  ];

  return (
    <div className="grid grid-cols-2 gap-2 h-full">
      {infoItems.map((item, idx) => {
        const Icon = item.icon;
        return (
          <div
            key={idx}
            className="p-2 rounded-xl bg-black/30 border border-white/5 flex items-center gap-2.5"
          >
            <div className={`p-1.5 rounded-lg bg-white/5 ${item.color}`}>
              <Icon size={15} />
            </div>
            <div className="min-w-0">
              <span className="text-[10px] text-gray-400 block truncate leading-tight">
                {item.label}
              </span>
              <span className="text-xs font-bold text-white font-mono truncate block">
                {item.value}
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
};
