'use client';

import React, { useState, useEffect } from 'react';
import { 
  WidgetLayoutItem, 
  SystemStats, 
  DockerContainerInfo, 
  MediaSession, 
  AppItemDto, 
  IntegrationStatusDto 
} from '@/types';
import { SystemOverviewWidget } from '../widgets/SystemOverviewWidget';
import { DockerContainersWidget } from '../widgets/DockerContainersWidget';
import { MediaServerWidget } from '../widgets/MediaServerWidget';
import { AppsWidget } from '../widgets/AppsWidget';
import { DockerOverviewWidget } from '../widgets/DockerOverviewWidget';
import { ServerInfoWidget } from '../widgets/ServerInfoWidget';
import { ApiIntegrationsWidget } from '../widgets/ApiIntegrationsWidget';
import { QuickActionsWidget } from '../widgets/QuickActionsWidget';
import { MarketplaceSidebar } from '../marketplace/MarketplaceSidebar';
import { 
  GripHorizontal, 
  X, 
  Maximize2, 
  Minimize2, 
  SlidersHorizontal,
  ArrowUpDown,
  Move,
  Trash2,
  PlusCircle,
  RotateCcw
} from 'lucide-react';

interface Props {
  editMode: boolean;
  setEditMode: (v: boolean) => void;
  openAddModal: boolean;
  setOpenAddModal: (v: boolean) => void;
}

export const DashboardGrid: React.FC<Props> = ({
  editMode,
  setEditMode,
  openAddModal,
  setOpenAddModal,
}) => {
  const [layout, setLayout] = useState<WidgetLayoutItem[]>([]);
  const [stats, setStats] = useState<SystemStats | null>(null);
  const [containers, setContainers] = useState<DockerContainerInfo[]>([]);
  const [sessions, setSessions] = useState<MediaSession[]>([]);
  const [apps, setApps] = useState<AppItemDto[]>([]);
  const [integrations, setIntegrations] = useState<IntegrationStatusDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);

  // Fetch initial layout and data
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [layoutRes, systemRes, dockerRes, mediaRes, appsRes, integRes] = await Promise.all([
          fetch('/api/dashboard/layout'),
          fetch('/api/system'),
          fetch('/api/docker/containers'),
          fetch('/api/integrations/media'),
          fetch('/api/apps'),
          fetch('/api/integrations'),
        ]);

        if (layoutRes.ok) {
          const lData = await layoutRes.json();
          setLayout(lData.layout || []);
        }

        if (systemRes.ok) {
          const sData = await systemRes.json();
          setStats(sData);
        }

        if (dockerRes.ok) {
          const dData = await dockerRes.json();
          setContainers(dData.containers || []);
        }

        if (mediaRes.ok) {
          const mData = await mediaRes.json();
          setSessions(mData.sessions || []);
        }

        if (appsRes.ok) {
          const aData = await appsRes.json();
          setApps(aData.apps || []);
        }

        if (integRes.ok) {
          const iData = await integRes.json();
          setIntegrations(iData.integrations || []);
        }
      } catch (err) {
        console.error('Error fetching dashboard state:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    // Auto-refresh metrics every 5 seconds
    const interval = setInterval(async () => {
      try {
        const sysRes = await fetch('/api/system');
        if (sysRes.ok) {
          const s = await sysRes.json();
          setStats(s);
        }
      } catch {
        // silent
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  // Save layout to backend
  const saveLayoutToDb = async (newLayout: WidgetLayoutItem[]) => {
    setLayout(newLayout);
    try {
      await fetch('/api/dashboard/layout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ layout: newLayout }),
      });
    } catch (err) {
      console.error('Failed to save layout:', err);
    }
  };

  const handleDragStart = (e: React.DragEvent, index: number) => {
    if (!editMode) return;
    setDraggedIndex(index);
    e.dataTransfer.setData('text/plain', index.toString());
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    if (!editMode) return;
    e.preventDefault();
    setDragOverIndex(index);
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    if (!editMode || draggedIndex === null) return;
    e.preventDefault();

    const items = [...layout];
    const [moved] = items.splice(draggedIndex, 1);
    items.splice(targetIndex, 0, moved);

    setDraggedIndex(null);
    setDragOverIndex(null);
    saveLayoutToDb(items);
  };

  const handleRemoveWidget = (id: string) => {
    const updated = layout.filter(w => w.id !== id);
    saveLayoutToDb(updated);
  };

  const handleAddWidgetType = (type: WidgetLayoutItem['type'], title: string) => {
    const newWidget: WidgetLayoutItem = {
      id: `w-${Date.now()}`,
      type,
      title,
      x: 0,
      y: 0,
      w: 4,
      h: 4,
      visible: true,
    };
    saveLayoutToDb([...layout, newWidget]);
    setOpenAddModal(false);
  };

  const renderWidgetContent = (type: string) => {
    switch (type) {
      case 'system-overview':
        return <SystemOverviewWidget stats={stats} loading={loading} />;
      case 'docker-containers':
        return <DockerContainersWidget containers={containers} loading={loading} />;
      case 'media-server':
        return <MediaServerWidget sessions={sessions} loading={loading} />;
      case 'apps':
        return <AppsWidget apps={apps} loading={loading} />;
      case 'docker-overview':
        return <DockerOverviewWidget containers={containers} />;
      case 'server-info':
        return <ServerInfoWidget stats={stats} />;
      case 'api-integrations':
        return <ApiIntegrationsWidget integrations={integrations} />;
      case 'quick-actions':
        return <QuickActionsWidget />;
      default:
        return <div className="text-sm text-gray-500">Widget-Inhalt bereit.</div>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Dashboard Title */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-wide flex items-center gap-2">
            Dashboard
          </h2>
          <p className="text-xs text-gray-400">
            Alle Dienste auf einen Blick – Dein Unraid Server
          </p>
        </div>

        {/* Edit mode indicator bar */}
        {editMode && (
          <div className="flex items-center gap-3 p-2 px-3 rounded-xl bg-red-950/70 border border-red-500/50 shadow-neon-red animate-in fade-in">
            <span className="flex items-center gap-1.5 text-xs text-red-200 font-semibold">
              <Move size={14} className="text-shadow-red animate-pulse" />
              Widgets verschiebbar & konfigurierbar
            </span>
            <button
              onClick={() => setEditMode(false)}
              className="px-2.5 py-1 text-[11px] font-bold bg-white text-red-950 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Fertig
            </button>
          </div>
        )}
      </div>

      {/* Main Grid + Marketplace Sidebar Container */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Left/Center Widgets Area (8 cols on XL) */}
        <div className="xl:col-span-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {layout.map((item, index) => {
              const isDragging = draggedIndex === index;
              const isOver = dragOverIndex === index;

              // Size classes based on width
              let colSpan = 'col-span-1';
              if (item.w >= 6 || item.type === 'api-integrations') colSpan = 'col-span-1 md:col-span-2';
              if (item.type === 'quick-actions') colSpan = 'col-span-1';

              return (
                <div
                  key={item.id}
                  draggable={editMode}
                  onDragStart={(e) => handleDragStart(e, index)}
                  onDragOver={(e) => handleDragOver(e, index)}
                  onDrop={(e) => handleDrop(e, index)}
                  className={`${colSpan} glass-panel rounded-2xl p-4 transition-all duration-200 relative group flex flex-col justify-between min-h-[260px] ${
                    editMode
                      ? 'border-dashed border-red-500/80 cursor-grab active:cursor-grabbing hover:border-red-400 shadow-neon-red'
                      : 'border-white/10 hover:border-red-500/30'
                  } ${isDragging ? 'opacity-40 scale-95' : ''} ${isOver ? 'ring-2 ring-red-500 scale-[1.02]' : ''}`}
                >
                  {/* Widget Card Header */}
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-white/5">
                    <div className="flex items-center gap-2">
                      {editMode && (
                        <span className="p-1 rounded bg-red-950/60 text-red-400 cursor-grab">
                          <GripHorizontal size={14} />
                        </span>
                      )}
                      <h3 className="text-xs font-bold text-white tracking-wide uppercase">
                        {item.title}
                      </h3>
                    </div>

                    {/* Edit mode card actions */}
                    {editMode ? (
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleRemoveWidget(item.id)}
                          className="p-1 rounded bg-red-950/80 hover:bg-red-900 text-red-300 transition-colors"
                          title="Widget entfernen"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    ) : (
                      <div className="w-1.5 h-1.5 rounded-full bg-red-600/60 group-hover:bg-red-500 transition-colors"></div>
                    )}
                  </div>

                  {/* Widget Body */}
                  <div className="flex-1">
                    {renderWidgetContent(item.type)}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Edit Mode Controls Panel (Matches screenshot bottom edit block) */}
          {editMode && (
            <div className="glass-panel rounded-2xl p-4 border border-dashed border-red-500/60 shadow-neon-red bg-[#0c0c12]/90 flex flex-wrap items-center justify-between gap-4 animate-in fade-in">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <SlidersHorizontal size={16} className="text-shadow-red" />
                  Edit Mode Aktiv
                </h4>
                <p className="text-xs text-gray-400">
                  Widgets können verschoben, in der Größe angepasst und neu angeordnet werden.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setOpenAddModal(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-red-600 hover:bg-red-500 text-white shadow-neon-red transition-all"
                >
                  <PlusCircle size={14} />
                  Neues Widget hinzufügen
                </button>
                <button
                  onClick={() => saveLayoutToDb(layout)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/20 text-white border border-white/15 transition-all"
                >
                  Layout speichern
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Marketplace Sidebar (4 cols on XL) */}
        <div className="xl:col-span-4 sticky top-20">
          <MarketplaceSidebar />
        </div>
      </div>

      {/* Add Widget Modal */}
      {openAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-lg bg-[#0e0e14] border border-[#ff1a35]/40 rounded-2xl shadow-neon-red-lg overflow-hidden p-6 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <h3 className="text-base font-bold text-white">Widget zum Dashboard hinzufügen</h3>
              <button
                onClick={() => setOpenAddModal(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 py-4 max-h-[60vh] overflow-y-auto">
              {[
                { type: 'system-overview', title: 'System Overview', desc: 'CPU, RAM, Speicher und Bandbreite' },
                { type: 'docker-containers', title: 'Docker Container', desc: 'Laufende Dienste & Ressourcen' },
                { type: 'media-server', title: 'Media Server', desc: 'Jellyfin, Emby und Plex Streams' },
                { type: 'apps', title: 'Apps Übersicht', desc: 'Schnellstart für Unraid Web-UIs' },
                { type: 'docker-overview', title: 'Docker Übersicht', desc: 'Status-Ringchart & Containeranzahl' },
                { type: 'server-info', title: 'Server Info', desc: 'Unraid Version, Uptime, Disks' },
                { type: 'api-integrations', title: 'API Integrationen', desc: 'Verbindungsstatus aller Dienste' },
                { type: 'quick-actions', title: 'Quick Actions', desc: 'Schnellbefehle für Server & Container' },
              ].map((w, idx) => (
                <div
                  key={idx}
                  onClick={() => handleAddWidgetType(w.type as WidgetLayoutItem['type'], w.title)}
                  className="p-3 rounded-xl bg-black/40 hover:bg-red-950/30 border border-white/5 hover:border-red-500/40 cursor-pointer transition-all flex flex-col justify-between group"
                >
                  <h4 className="text-xs font-bold text-white group-hover:text-red-400 transition-colors">
                    {w.title}
                  </h4>
                  <p className="text-[10px] text-gray-400 mt-1">{w.desc}</p>
                  <span className="text-[10px] text-red-500 font-semibold mt-2 group-hover:underline">
                    + Hinzufügen
                  </span>
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-3 border-t border-white/10">
              <button
                onClick={() => setOpenAddModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/15 text-white"
              >
                Schließen
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
