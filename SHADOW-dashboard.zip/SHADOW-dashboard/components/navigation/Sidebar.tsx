'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { 
  Home, 
  Layers, 
  Container, 
  Cpu, 
  Network, 
  HardDrive, 
  Puzzle, 
  Store, 
  FileText, 
  ShieldCheck, 
  Bell, 
  Settings,
  ChevronLeft,
  ChevronRight,
  Server
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ collapsed, setCollapsed, mobileOpen, setMobileOpen }) => {
  const pathname = usePathname();

  const navItems = [
    { label: 'Home', href: '/', icon: Home },
    { label: 'Apps', href: '/apps', icon: Layers },
    { label: 'Docker', href: '/docker', icon: Container },
    { label: 'System', href: '/system', icon: Cpu },
    { label: 'Netzwerk', href: '/netzwerk', icon: Network },
    { label: 'Speicher', href: '/speicher', icon: HardDrive },
    { label: 'Plugins', href: '/plugins', icon: Puzzle },
    { label: 'Marktplatz', href: '/marktplatz', icon: Store },
    { label: 'Logs', href: '/logs', icon: FileText },
    { label: 'Backup', href: '/backup', icon: ShieldCheck },
    { label: 'Benachrichtigungen', href: '/benachrichtigungen', icon: Bell },
    { label: 'Einstellungen', href: '/einstellungen', icon: Settings },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div 
          className="fixed inset-0 bg-black/80 z-40 lg:hidden backdrop-blur-sm"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 flex flex-col justify-between transition-all duration-300 border-r border-[#ff1a35]/20 bg-[#08080c]/95 backdrop-blur-xl ${
          collapsed ? 'w-20' : 'w-64'
        } ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
      >
        {/* Brand Header */}
        <div>
          <div className="flex items-center justify-between p-4 border-b border-[#ff1a35]/15">
            <Link href="/" className="flex items-center gap-3 group">
              <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-red-600 to-[#40000a] p-[1px] shadow-neon-red">
                <div className="w-full h-full bg-[#0d0d12] rounded-lg flex items-center justify-center">
                  <span className="font-black text-xl text-shadow-red group-hover:scale-110 transition-transform tracking-tighter">S</span>
                </div>
              </div>
              {!collapsed && (
                <div>
                  <h1 className="text-lg font-black tracking-widest text-white flex items-center gap-1.5">
                    SHADOW
                  </h1>
                  <p className="text-[9px] font-semibold tracking-wider text-red-500/80 uppercase">
                    UNRAID DASHBOARD
                  </p>
                </div>
              )}
            </Link>

            <button
              onClick={() => setCollapsed(!collapsed)}
              className="hidden lg:flex items-center justify-center w-7 h-7 rounded-md text-gray-400 hover:text-white hover:bg-white/5 transition-colors border border-white/5"
              title={collapsed ? 'Erweitern' : 'Minimieren'}
            >
              {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-210px)]">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center gap-3.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group ${
                    isActive
                      ? 'bg-gradient-to-r from-red-600/25 to-transparent text-white border-l-2 border-shadow-red shadow-sm'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                  title={collapsed ? item.label : undefined}
                >
                  <Icon
                    size={19}
                    className={`transition-colors ${
                      isActive ? 'text-shadow-red' : 'text-gray-400 group-hover:text-red-400'
                    }`}
                  />
                  {!collapsed && <span className="truncate">{item.label}</span>}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Server Status Footer */}
        <div className="p-3 border-t border-[#ff1a35]/15 bg-[#0a0a0f]">
          <div className={`flex items-center gap-3 p-2.5 rounded-xl border border-white/5 bg-[#121218]/60 ${collapsed ? 'justify-center' : ''}`}>
            <div className="relative">
              <div className="w-8 h-8 rounded-lg bg-red-950/60 border border-red-500/30 flex items-center justify-center text-red-400">
                <Server size={17} />
              </div>
              <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-[#08080c] animate-pulse"></span>
            </div>

            {!collapsed && (
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-gray-200 truncate">Unraid Server</span>
                  <span className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-medium text-emerald-400 bg-emerald-950/50 rounded">
                    Online
                  </span>
                </div>
                <p className="text-[10px] text-gray-400 truncate">Version 7.3.2</p>
              </div>
            )}
          </div>

          {!collapsed && (
            <div className="mt-2.5 text-center">
              <span className="text-[10px] text-gray-500 font-mono">
                SHADOW v1.0.0 · Made for Unraid
              </span>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
