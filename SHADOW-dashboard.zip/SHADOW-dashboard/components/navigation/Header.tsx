'use client';

import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  SlidersHorizontal, 
  PlusCircle, 
  Bell, 
  Settings, 
  Menu, 
  HardDrive, 
  CheckCircle,
  X,
  ExternalLink,
  Layers,
  Container,
  Cpu
} from 'lucide-react';
import Link from 'next/link';

interface HeaderProps {
  editMode: boolean;
  setEditMode: (v: boolean) => void;
  onOpenAddWidget: () => void;
  setMobileOpen: (v: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  editMode,
  setEditMode,
  onOpenAddWidget,
  setMobileOpen,
}) => {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Array<{ id: string; title: string; message: string; timestamp: string }>>([
    { id: '1', title: 'Unraid Status', message: 'Alle 6 Festplatten im Array fehlerfrei.', timestamp: 'vor 5 Min.' },
    { id: '2', title: 'Jellyfin Server', message: '3 aktive Streams werden abgespielt.', timestamp: 'vor 12 Min.' },
    { id: '3', title: 'Backup erledigt', message: 'Konfigurations-Snapshot erfolgreich erstellt.', timestamp: 'vor 1 Std.' },
  ]);

  const searchInputRef = useRef<HTMLInputElement>(null);

  // Global hotkey "K" to search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.key === 'k' || e.key === 'K') && !['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
        e.preventDefault();
        setSearchOpen(true);
        setTimeout(() => searchInputRef.current?.focus(), 50);
      }
      if (e.key === 'Escape') {
        setSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const searchResults = [
    { name: 'Jellyfin', type: 'App / Container', link: '/apps', icon: Layers },
    { name: 'Emby Media Server', type: 'Container', link: '/docker', icon: Container },
    { name: 'Sonarr TV PVR', type: 'Integration', link: '/apps', icon: Layers },
    { name: 'Array Speicherkapazität', type: 'System', link: '/speicher', icon: HardDrive },
    { name: 'CPU & RAM Auslastung', type: 'System', link: '/system', icon: Cpu },
  ].filter(r => r.name.toLowerCase().includes(searchQuery.toLowerCase()) || r.type.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <>
      <header className="sticky top-0 z-30 h-16 border-b border-[#ff1a35]/15 bg-[#08080c]/80 backdrop-blur-xl px-4 lg:px-6 flex items-center justify-between gap-4">
        {/* Left: Mobile Toggle & Global Search */}
        <div className="flex items-center gap-3 flex-1 max-w-xl">
          <button
            onClick={() => setMobileOpen(true)}
            className="lg:hidden p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5"
          >
            <Menu size={20} />
          </button>

          {/* Quick Search Bar */}
          <div 
            onClick={() => {
              setSearchOpen(true);
              setTimeout(() => searchInputRef.current?.focus(), 50);
            }}
            className="relative flex items-center w-full max-w-md bg-[#101017] hover:bg-[#14141d] border border-white/10 hover:border-[#ff1a35]/40 rounded-xl px-3.5 py-1.5 cursor-pointer transition-all shadow-inner group"
          >
            <Search size={16} className="text-gray-400 group-hover:text-shadow-red transition-colors mr-2.5" />
            <span className="text-xs text-gray-400 select-none truncate">
              Suche nach Diensten, Containern, Plugins ...
            </span>
            <kbd className="ml-auto hidden sm:inline-flex items-center px-1.5 py-0.5 text-[10px] font-mono text-gray-400 bg-white/5 border border-white/10 rounded">
              K
            </kbd>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          {/* Edit Mode Toggle */}
          <button
            onClick={() => setEditMode(!editMode)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              editMode
                ? 'bg-red-600 text-white border-red-500 shadow-neon-red'
                : 'bg-[#101017] text-gray-300 border-white/10 hover:border-red-500/40 hover:text-white'
            }`}
          >
            <SlidersHorizontal size={14} className={editMode ? 'animate-spin' : ''} />
            <span className="hidden md:inline">Edit Mode</span>
            <div className={`w-2 h-2 rounded-full ${editMode ? 'bg-white' : 'bg-red-500'}`} />
          </button>

          {/* Add Widget Button */}
          <button
            onClick={onOpenAddWidget}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white shadow-neon-red transition-all"
          >
            <PlusCircle size={14} />
            <span className="hidden sm:inline">Widget hinzufügen</span>
          </button>

          {/* Notification Center */}
          <div className="relative">
            <button
              onClick={() => setNotificationsOpen(!notificationsOpen)}
              className="relative p-2 rounded-xl bg-[#101017] border border-white/10 hover:border-white/20 text-gray-400 hover:text-white transition-colors"
            >
              <Bell size={16} />
              <span className="absolute 1 top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full shadow-neon-red"></span>
            </button>

            {notificationsOpen && (
              <div className="absolute right-0 mt-2 w-80 bg-[#0d0d13] border border-[#ff1a35]/30 rounded-2xl shadow-2xl p-3 z-50 backdrop-blur-2xl">
                <div className="flex items-center justify-between pb-2 border-b border-white/10 mb-2">
                  <span className="text-xs font-bold text-white uppercase tracking-wider">Benachrichtigungen</span>
                  <button 
                    onClick={() => setNotifications([])}
                    className="text-[10px] text-red-400 hover:underline"
                  >
                    Alle leeren
                  </button>
                </div>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <p className="text-xs text-gray-500 text-center py-4">Keine neuen Meldungen</p>
                  ) : (
                    notifications.map((n) => (
                      <div key={n.id} className="p-2 bg-white/5 rounded-lg border border-white/5 text-xs">
                        <div className="flex justify-between items-center text-gray-300 font-semibold mb-0.5">
                          <span>{n.title}</span>
                          <span className="text-[10px] text-gray-500 font-normal">{n.timestamp}</span>
                        </div>
                        <p className="text-gray-400 text-[11px]">{n.message}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Quick Settings link */}
          <Link
            href="/einstellungen"
            className="p-2 rounded-xl bg-[#101017] border border-white/10 hover:border-white/20 text-gray-400 hover:text-white transition-colors"
            title="Einstellungen"
          >
            <Settings size={16} />
          </Link>

          {/* Server IP Badge */}
          <div className="hidden xl:flex items-center gap-2 px-3 py-1 rounded-xl bg-black/40 border border-[#ff1a35]/30">
            <div className="w-2 h-2 rounded-full bg-emerald-400"></div>
            <div className="flex flex-col text-right">
              <span className="text-[10px] text-gray-400 font-medium leading-none">Unraid IP</span>
              <span className="text-xs font-mono font-bold text-gray-200">192.168.178.10</span>
            </div>
          </div>
        </div>
      </header>

      {/* Global Search Modal */}
      {searchOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/80 backdrop-blur-md">
          <div className="w-full max-w-xl bg-[#0f0f16] border border-[#ff1a35]/40 rounded-2xl shadow-neon-red-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center px-4 py-3 border-b border-white/10">
              <Search size={18} className="text-red-500 mr-3" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Dienste, Container, Widgets, Plugins suchen ..."
                className="w-full bg-transparent text-sm text-white placeholder-gray-500 focus:outline-none"
              />
              <button onClick={() => setSearchOpen(false)} className="text-gray-400 hover:text-white p-1">
                <X size={18} />
              </button>
            </div>

            <div className="p-3 max-h-80 overflow-y-auto">
              <p className="text-[10px] uppercase font-bold tracking-wider text-gray-500 px-2 mb-2">Ergebnisse</p>
              {searchResults.length === 0 ? (
                <div className="text-center py-6 text-sm text-gray-500">Keine Treffer für &quot;{searchQuery}&quot;</div>
              ) : (
                <div className="space-y-1">
                  {searchResults.map((item, idx) => {
                    const Icon = item.icon;
                    return (
                      <Link
                        key={idx}
                        href={item.link}
                        onClick={() => setSearchOpen(false)}
                        className="flex items-center justify-between p-2.5 rounded-xl hover:bg-white/5 border border-transparent hover:border-[#ff1a35]/30 group transition-all"
                      >
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-red-950/40 text-red-400 border border-red-500/20 group-hover:scale-105 transition-transform">
                            <Icon size={16} />
                          </div>
                          <div>
                            <p className="text-xs font-semibold text-white group-hover:text-red-400 transition-colors">
                              {item.name}
                            </p>
                            <p className="text-[10px] text-gray-400">{item.type}</p>
                          </div>
                        </div>
                        <ExternalLink size={14} className="text-gray-500 group-hover:text-white" />
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between px-4 py-2 border-t border-white/5 bg-[#08080c] text-[10px] text-gray-500">
              <span>Drücke ESC zum Schließen</span>
              <span>SHADOW Omnisearch</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
