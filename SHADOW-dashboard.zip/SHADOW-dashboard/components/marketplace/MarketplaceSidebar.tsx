'use client';

import React, { useState, useEffect } from 'react';
import { MarketplacePlugin } from '@/types';
import { 
  Store, 
  Search, 
  DownloadCloud, 
  Check, 
  Star, 
  ExternalLink,
  Layers,
  ArrowRight,
  Sparkles
} from 'lucide-react';

export const MarketplaceSidebar: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'Docker.io' | 'Custom' | 'Community'>('Docker.io');
  const [activeCategory, setActiveCategory] = useState<string>('Alle');
  const [searchQuery, setSearchQuery] = useState('');
  const [items, setItems] = useState<MarketplacePlugin[]>([]);
  const [installingId, setInstallingId] = useState<string | null>(null);
  const [installedMap, setInstalledMap] = useState<Record<string, boolean>>({
    jellyfin: true,
    emby: true,
    sonarr: true,
    radarr: true,
    qbittorrent: true,
    'home-assistant': true,
    immich: true,
  });

  const categories = ['Alle', 'Media', 'Tools', 'System', 'Netzwerk'];

  useEffect(() => {
    const fetchMarketplace = async () => {
      try {
        const res = await fetch(`/api/marketplace?tab=${activeTab}&category=${activeCategory}&q=${searchQuery}`);
        if (res.ok) {
          const data = await res.json();
          setItems(data.items || []);
        }
      } catch (err) {
        console.error('Failed to load marketplace items:', err);
      }
    };
    fetchMarketplace();
  }, [activeTab, activeCategory, searchQuery]);

  const handleInstall = (id: string) => {
    setInstallingId(id);
    setTimeout(() => {
      setInstalledMap(prev => ({ ...prev, [id]: true }));
      setInstallingId(null);
    }, 1200);
  };

  return (
    <div className="glass-panel rounded-2xl p-4 flex flex-col h-full border border-[#ff1a35]/25">
      {/* Title */}
      <div className="flex items-center justify-between pb-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-red-950/60 border border-red-500/30 text-shadow-red">
            <Store size={16} />
          </div>
          <h3 className="text-sm font-bold text-white tracking-wide">Plugin / Marktplatz</h3>
        </div>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-3 gap-1 my-3 p-1 rounded-xl bg-black/50 border border-white/5">
        {(['Docker.io', 'Custom', 'Community'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeTab === tab
                ? 'bg-red-600 text-white shadow-neon-red'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Search Input */}
      <div className="relative mb-3">
        <Search size={14} className="absolute left-3 top-2.5 text-gray-500" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Plugin suchen ..."
          className="w-full bg-[#101017] border border-white/10 focus:border-red-500/50 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none transition-colors"
        />
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-3 scrollbar-none text-[11px]">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-all ${
              activeCategory === cat
                ? 'bg-white/10 text-white border border-red-500/40'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Plugin List */}
      <div className="space-y-2.5 overflow-y-auto max-h-[440px] pr-1">
        {items.map((item) => {
          const isInstalled = installedMap[item.id];
          const isInstalling = installingId === item.id;

          return (
            <div
              key={item.id}
              className="p-3 rounded-xl bg-[#101017]/90 border border-white/5 hover:border-red-500/30 transition-all flex items-center justify-between gap-3 group"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-red-950/40 border border-red-500/20 flex items-center justify-center text-red-400 flex-shrink-0 font-bold text-xs">
                  {item.name.substring(0, 2).toUpperCase()}
                </div>
                <div className="min-w-0">
                  <h4 className="text-xs font-bold text-white truncate group-hover:text-red-400 transition-colors">
                    {item.name}
                  </h4>
                  <div className="flex items-center gap-2 text-[10px] text-gray-400">
                    <span>{item.category}</span>
                    <span>•</span>
                    <span className="flex items-center gap-0.5 text-amber-400 font-medium">
                      <Star size={10} fill="currentColor" /> {item.rating || 4.5}
                    </span>
                  </div>
                </div>
              </div>

              {/* Install Button */}
              <button
                disabled={isInstalled || isInstalling}
                onClick={() => handleInstall(item.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all flex-shrink-0 ${
                  isInstalled
                    ? 'bg-white/5 text-gray-400 border border-white/10 cursor-default'
                    : isInstalling
                    ? 'bg-red-950 text-red-400 border border-red-500/40 animate-pulse'
                    : 'bg-red-600 hover:bg-red-500 text-white shadow-neon-red'
                }`}
              >
                {isInstalled ? (
                  <>
                    <Check size={12} className="text-emerald-400" />
                    <span className="text-[11px]">Installiert</span>
                  </>
                ) : isInstalling ? (
                  <span className="text-[11px]">Laden...</span>
                ) : (
                  <>
                    <DownloadCloud size={12} />
                    <span className="text-[11px]">Installieren</span>
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>

      {/* Weitere Integrationen Footer */}
      <div className="mt-auto pt-3 border-t border-white/10">
        <div className="flex items-center justify-between text-xs font-semibold text-gray-300 mb-2">
          <span>Weitere Integrationen</span>
          <a href="/marktplatz" className="text-red-400 hover:underline flex items-center gap-1 text-[11px]">
            Alle anzeigen <ArrowRight size={11} />
          </a>
        </div>
        <div className="grid grid-cols-4 gap-2">
          {['GitHub', 'Grafana', 'InfluxDB', 'Nextcloud'].map((service, idx) => (
            <div
              key={idx}
              className="p-1.5 rounded-lg bg-black/40 border border-white/5 hover:border-red-500/30 text-center transition-all cursor-pointer group"
            >
              <span className="text-[10px] text-gray-400 group-hover:text-white block truncate">
                {service}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
