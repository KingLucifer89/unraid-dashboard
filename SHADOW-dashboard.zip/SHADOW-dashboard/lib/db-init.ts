import { prisma } from './prisma';
import { DEFAULT_LAYOUT, DEFAULT_APPS, MARKETPLACE_ITEMS } from './default-data';

let initialized = false;

export async function ensureDatabaseInitialized() {
  if (initialized) return;

  try {
    // Check if layout exists
    const layout = await prisma.dashboardLayout.findUnique({
      where: { id: 'default' }
    });

    if (!layout) {
      await prisma.dashboardLayout.create({
        data: {
          id: 'default',
          name: 'SHADOW Standard Layout',
          layoutJson: JSON.stringify(DEFAULT_LAYOUT),
          isDefault: true,
        }
      });
    }

    // Check apps
    const countApps = await prisma.appItem.count();
    if (countApps === 0) {
      for (const app of DEFAULT_APPS) {
        await prisma.appItem.create({
          data: {
            id: app.id,
            name: app.name,
            url: app.url,
            category: app.category,
            description: app.description,
            color: app.color,
            openNewTab: app.openNewTab,
            status: app.status,
            order: app.order,
            icon: app.icon,
          }
        });
      }
    }

    // Check default integrations
    const integrationsCount = await prisma.integrationConfig.count();
    if (integrationsCount === 0) {
      const defaultConfigs = [
        { id: 'jellyfin', name: 'Jellyfin', type: 'media', url: 'http://192.168.178.10:8096', enabled: true, lastStatus: 'connected' },
        { id: 'emby', name: 'Emby', type: 'media', url: 'http://192.168.178.10:8096', enabled: true, lastStatus: 'connected' },
        { id: 'sonarr', name: 'Sonarr', type: 'arr', url: 'http://192.168.178.10:8989', enabled: true, lastStatus: 'connected' },
        { id: 'radarr', name: 'Radarr', type: 'arr', url: 'http://192.168.178.10:7878', enabled: true, lastStatus: 'connected' },
        { id: 'qbittorrent', name: 'qBittorrent', type: 'torrent', url: 'http://192.168.178.10:8080', enabled: true, lastStatus: 'connected' },
        { id: 'homeassistant', name: 'Home Assistant', type: 'smarthome', url: 'http://192.168.178.10:8123', enabled: true, lastStatus: 'connected' },
        { id: 'immich', name: 'Immich', type: 'monitoring', url: 'http://192.168.178.10:2283', enabled: true, lastStatus: 'connected' },
        { id: 'grafana', name: 'Grafana', type: 'monitoring', url: 'http://192.168.178.10:3000', enabled: true, lastStatus: 'connected' },
      ];

      for (const item of defaultConfigs) {
        await prisma.integrationConfig.create({
          data: {
            id: item.id,
            name: item.name,
            type: item.type,
            url: item.url,
            enabled: item.enabled,
            lastStatus: item.lastStatus,
          }
        });
      }
    }

    // Check notifications
    const notifCount = await prisma.notification.count();
    if (notifCount === 0) {
      await prisma.notification.createMany({
        data: [
          { title: 'SHADOW Dashboard gestartet', message: 'System läuft erfolgreich auf Port 8086.', level: 'info', source: 'system' },
          { title: 'Docker Subsystem online', message: 'Docker Socket /var/run/docker.sock erfolgreich angebunden.', level: 'info', source: 'docker' },
        ]
      });
    }

    initialized = true;
  } catch (err) {
    console.error('Error initializing database defaults:', err);
  }
}
